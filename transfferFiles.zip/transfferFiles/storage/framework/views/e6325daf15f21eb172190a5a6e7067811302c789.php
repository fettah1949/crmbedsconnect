<?php if($page_name != 'coming_soon' && $page_name != 'contact_us' && $page_name != 'error404' && $page_name != 'error500' && $page_name != 'error503' && $page_name != 'faq' && $page_name != 'helpdesk' && $page_name != 'maintenence' && $page_name != 'privacy' && $page_name != 'auth_boxed' && $page_name != 'auth_default'): ?>
    <!--  BEGIN SIDEBAR  -->
    
    <!--  END SIDEBAR  -->


    <!--  BEGIN FOOTER  -->
    <div class="footer-wrapper">
        <div class="footer-section f-section-1">
            <p class="">Copyright © 2022 <a target="_blank" >BDSCONNECT CRM</a>, All rights reserved.</p>
        </div>
        
    </div>
    <!--  END FOOTER  -->

<?php endif; ?><?php /**PATH /home2/bedscect/ops.bedsconnect.com/resources/views/inc/footer.blade.php ENDPATH**/ ?>