<?php

use App\Models\Country;
$countries = Country::all();


use App\Models\Agencycontact;
$sellers = Agencycontact::where('Contact_Type','SELLER')->get();

    $category_name = 'production';
    $page_name = 'hotel_list';
    $has_scrollspy = 0;
    $scrollspy_offset = '';

?>


   
<?php $__env->startSection('content'); ?>

<br>

<nav class="breadcrumb-two" aria-label="breadcrumb">
    <ol style="background: none" class="breadcrumb">
        <li class="breadcrumb-item active"><a href="<?php echo e(route('hotellist.index')); ?>">Hotel List</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">Edit Hotel: <?php echo e($hotellist->Hotel_Name); ?></a></li>
    </ol>
</nav>
 
<hr>
   
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
 
        
    <form action="<?php echo e(route('hotellist.update',$hotellist->id)); ?>" method="POST" >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="row">

        <div class="form-group col-sm-auto">
            <label>Hotel Code</label>
            <input disabled type="text" class="form-control"  placeholder="Hotel Code" name="Hotel_Code" value="<?php echo e($hotellist->Hotel_Code); ?>">
            <?php $__errorArgs = ['Hotel_Code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
            <div class="form-group col-sm-auto">
                <label>bdc_id</label>
                <input type="text" class="form-control"  name="bdc_id" value="<?php echo e($hotellist->bdc_id); ?>" placeholder="bdc_id">
                <?php $__errorArgs = ['bdc_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        
    
        <div class="form-group col-sm-auto">
            <label>Giata id</label>
            <input type="text" class="form-control"  name="Giata_id" value="<?php echo e($hotellist->Giata_id); ?>" placeholder="Giata id">
            <?php $__errorArgs = ['Giata_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group col-sm-auto">
            <label>Seller id</label>
            <input type="text" class="form-control"  name="provider_id" value="<?php echo e($hotellist->provider_id); ?>" placeholder="Seller id">
            <?php $__errorArgs = ['provider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>
    
    <hr>


    <div class="row">
        <div class="form-group col-sm-auto">
            <label>Hotel Name</label>
            <input type="text" class="form-control"  name="Hotel_Name" value="<?php echo e($hotellist->Hotel_Name); ?>" placeholder="Hotel Name">
            <?php $__errorArgs = ['Hotel_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label>Latitude</label>
            <input type="text" class="form-control"  name="Latitude" value="<?php echo e($hotellist->Latitude); ?>" placeholder="Latitude">
            <?php $__errorArgs = ['Latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label>Longitude</label>
            <input type="text" class="form-control"  name="Longitude" value="<?php echo e($hotellist->Longitude); ?>" placeholder="Longitude">
            <?php $__errorArgs = ['Longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label>Address</label>
            <input type="text" class="form-control"  name="Address" value="<?php echo e($hotellist->Address); ?>" placeholder="Address">
            <?php $__errorArgs = ['Address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    
    <hr>


    <div class="row">
        <div class="form-group col-sm-auto">
            <label>City</label>
            <input type="text" class="form-control"  name="City" value="<?php echo e($hotellist->City); ?>" placeholder="City">
            <?php $__errorArgs = ['City'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label>Zip Code</label>
            <input type="text" class="form-control"  name="Zip_Code" value="<?php echo e($hotellist->Zip_Code); ?>" placeholder="Zip Code">
            <?php $__errorArgs = ['Zip_Code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label>Email</label>
            <input type="text" class="form-control"  name="Email" value="<?php echo e($hotellist->Email); ?>" placeholder="Email">
            <?php $__errorArgs = ['Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label>Country</label>
                <input class="form-control" id="Country" placeholder="Select Country"  value="<?php echo e($hotellist->Country); ?>" name="Country" type="text" list="select-contry" onchange='setCountryCode();'>
                <datalist id="select-contry">
                <option value="">Select Country</option>
                 <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <input type=hidden  id="<?php echo e($country->nom_en_gb); ?>" value="<?php echo e($country->alpha2); ?>" />
                     <option value="<?php echo e($country->nom_en_gb); ?>"><?php echo e($country->nom_en_gb); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </datalist>
            <?php $__errorArgs = ['Country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    
    <hr>


    <div class="row">
        
                <div class="form-group col-sm-auto">
                    <label>Country Code</label>
                    <input type="text" class="form-control" id="Country_Code"  value="<?php echo e($hotellist->Country_Code); ?>"  name="Country_Code" placeholder="Country Code">
                    <?php $__errorArgs = ['Country_Code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
        
                <div class="form-group col-sm-auto">
                    <label>Seller</label>
                        <input class="form-control" placeholder="Select Seller" name="provider" type="text" list="select-seller"  value="<?php echo e($hotellist->provider); ?>" >
                        <datalist id="select-seller">
                        <option value="">Select Seller</option>
                         <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <option value="<?php echo e($seller->Agency_Name); ?>"><?php echo e($seller->Agency_Name); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>
                    <?php $__errorArgs = ['provider'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
    
    </div>    
    
    <hr>

    

        <div class="col-xs-12 col-sm-12 col-md-12">
            <button type="submit" class="btn btn-outline-success mb-2">Update</button>
            <a style="margin-left: 10px" href="<?php echo e(route('hotellist.index')); ?>" class="btn btn-outline-dark mb-2">Cancel</a>
          </div>
 
      </form>
      <hr>
<script>
     
        function setCountryCode(){
            var c_code = document.getElementById("Country").value;
        document.getElementById("Country_Code").value = document.getElementById(c_code).value ;      
        }
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/bedscect/ops.bedsconnect.com/resources/views/admin/hotels/edit.blade.php ENDPATH**/ ?>