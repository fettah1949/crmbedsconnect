<?php
use App\Models\Country;
$countries = Country::all();

use App\Models\Agencycontact;
$sellers = Agencycontact::where('Contact_Type','SELLER')->get();
//dd($sellers);

    $category_name = 'production';
    $page_name = 'hotel_list';
    $has_scrollspy = 0;
    $scrollspy_offset = '';
?>

  
<?php $__env->startSection('content'); ?>
<br>

<nav class="breadcrumb-two" aria-label="breadcrumb">
    <ol style="background: none" class="breadcrumb">
        <li class="breadcrumb-item active"><a href="<?php echo e(route('hotellist.index')); ?>">Hotel List</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">Add New Hotel</a></li>
    </ol>
</nav>
 
<hr>
   
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
   
<form action="<?php echo e(route('hotellist.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
  
    <div class="row">
        <div class="form-group col-sm-auto">
            <label for="exampleFormControlInput">Hotel Code</label>
            <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Hotel Code" name="Hotel_Code">
            <?php $__errorArgs = ['Hotel_Code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
            <div class="form-group col-sm-auto">
                <label for="exampleFormControlInput">bdc_id</label>
                <input type="text" class="form-control" id="exampleFormControlInput" name="bdc_id" placeholder="bdc_id">
                <?php $__errorArgs = ['bdc_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        
    
        <div class="form-group col-sm-auto">
            <label for="exampleFormControlInput">Giata id</label>
            <input type="text" class="form-control" id="exampleFormControlInput" name="Giata_id" placeholder="Giata id">
            <?php $__errorArgs = ['Giata_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group col-sm-auto">
            <label for="exampleFormControlInput">Seller id</label>
            <input type="text" class="form-control" id="exampleFormControlInput" name="provider_id" placeholder="Seller id">
            <?php $__errorArgs = ['provider_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    
    <hr>


    <div class="row">
        <div class="form-group col-sm-auto">
            <label for="exampleFormControlInput">Hotel Name</label>
            <input type="text" class="form-control" id="exampleFormControlInput" name="Hotel_Name" placeholder="Hotel Name">
            <?php $__errorArgs = ['Hotel_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label for="exampleFormControlInput">Latitude</label>
            <input type="text" class="form-control" id="exampleFormControlInput" name="Latitude" placeholder="Latitude">
            <?php $__errorArgs = ['Latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label for="exampleFormControlInput">Longitude</label>
            <input type="text" class="form-control" id="exampleFormControlInput" name="Longitude" placeholder="Longitude">
            <?php $__errorArgs = ['Longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label for="exampleFormControlInput">Address</label>
            <input type="text" class="form-control" id="exampleFormControlInput" name="Address" placeholder="Address">
            <?php $__errorArgs = ['Address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    
    <hr>


    <div class="row">
        <div class="form-group col-sm-auto">
            <label for="exampleFormControlInput">City</label>
            <input type="text" class="form-control" id="exampleFormControlInput" name="City" placeholder="City">
            <?php $__errorArgs = ['City'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label for="exampleFormControlInput">Zip Code</label>
            <input type="text" class="form-control" id="exampleFormControlInput" name="Zip_Code" placeholder="Zip Code">
            <?php $__errorArgs = ['Zip_Code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label for="exampleFormControlInput">Email</label>
            <input type="text" class="form-control" id="exampleFormControlInput" name="Email" placeholder="Email">
            <?php $__errorArgs = ['Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label for="exampleFormControlInput">Country</label>
            <input class="form-control" type="text" list="select-contry" id="Country" name="Country" placeholder="Select Country" onkeyup='setCountryCode();'>
            <datalist  id="select-contry">
            <option value="">Select Country</option>
             <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <input type=hidden  id="<?php echo e($country->nom_en_gb); ?>" value="<?php echo e($country->alpha2); ?>" />
                 <option value="<?php echo e($country->nom_en_gb); ?>"><?php echo e($country->nom_en_gb); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </datalist>
            <?php $__errorArgs = ['Country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    
    <hr>


    <div class="row">
        <div class="form-group col-sm-auto">
            <label >Country Code</label>
            <input type="text" class="form-control" id="Country_Code" name="Country_Code" placeholder="Country Code">
            <?php $__errorArgs = ['Country_Code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label for="exampleFormControlInput">Seller</label>
            <input class="form-control" type="text" placeholder="Select Seller" list="select-seller" name="provider" >
            <datalist id="select-seller">
            <option value="">Select Seller</option>
             <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($seller->Agency_Name); ?>"><?php echo e($seller->Agency_Name); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </datalist>
            <?php $__errorArgs = ['provider'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    
    <hr>


                <div class="col-xs-12 col-sm-12 col-md-12 text-center">

                    <button type="submit" class="btn btn-outline-success mb-2">Save</button>
                    <button style="margin-left: 20px" type="reset" class="btn btn-outline-danger mb-2">Clear</button>
                
                </div>
</form>
<script>
      function setCountryCode(){
            var c_code = document.getElementById("Country").value;
        document.getElementById("Country_Code").value = document.getElementById(c_code).value ;      
        }
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/bedscect/ops.bedsconnect.com/resources/views/admin/hotels/create.blade.php ENDPATH**/ ?>