<?php
use App\Models\Bank;
$banks = Bank::all();

use App\Models\ExpenseCategory;
$categories = ExpenseCategory::all();

    $category_name = 'finance';
    $page_name = 'expense';
    $has_scrollspy = 0;
    $scrollspy_offset = '';
?>

  
<?php $__env->startSection('content'); ?>
<br>

<nav class="breadcrumb-two" aria-label="breadcrumb">
    <ol style="background: none" class="breadcrumb">
        <li class="breadcrumb-item active"><a href="<?php echo e(route('expense.index')); ?>">Expenses</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">New Expense</a></li>
    </ol>
</nav>
 
<hr>
   
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
   
<form action="<?php echo e(route('expense.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
  
    <div class="row">
        
            <div class="form-group col-sm-auto">
                <label for="exampleFormControlInput">Date</label>
                <input type="date" class="form-control" id="exampleFormControlInput" name="Expense_Date">
                <?php $__errorArgs = ['Expense_Date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group col-sm-auto">
                <label for="exampleFormControlInput">Category :</label>
            
                <input class="form-control" id="category" placeholder="Select Category" name="Category" type="text" list="select-category">
                 <datalist id="select-category">
                 
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($category->Category_Name); ?>"><?php echo e($category->Category_Name); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </datalist>  
                <?php $__errorArgs = ['Category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
             

            <div class="form-group col-sm-auto">
                <label for="description">Description</label>
                <input type="text" class="form-control" id="description" name="description" placeholder="Description">
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
             
        
            <div class="form-group col-sm-auto">
                <label>Payment Mode :</label>
                <select class="form-control" id="payment_mode" name="Payment_Mode" >
                <option value="">Select Payment</option>
                <option value="CASH">Cash</option>
                <option value="BANK">Bank</option>
            </select>
            <?php $__errorArgs = ['Payment_Mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        
        
        
            </div>
            
            <hr>
            
      
    


<div class="row" >
    
    <div class="form-group col-sm-auto">
        <label for="exampleFormControlInput">Paid Through :</label>
    
        <input class="form-control" id="bank" placeholder="Select Bank" name="Bank" type="text" list="select-bank" onkeyup='setBank();'>
         <datalist id="select-bank">
         
            <option value="">Select Bank</option>
             <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <input hidden type="text" id="<?php echo e($bank->Nom_du_compte); ?>2" value="<?php echo e($bank->id); ?>">
             <input hidden type="text" id="<?php echo e($bank->Nom_du_compte); ?>" value="<?php echo e($bank->Devise); ?>">
             <option value="<?php echo e($bank->Nom_du_compte); ?>"><?php echo e($bank->Nom_du_compte); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </datalist>  
        <?php $__errorArgs = ['Bank'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

  
    <div class="form-group col-sm-auto">
        <label for="amount">Amount</label>


        <div class="input-group mb-4">
            <input type="decimal" class="form-control" aria-label="Default" aria-describedby="currency" id="amount" placeholder="0.00" name="Amount">
            <div class="input-group-prepend">
              <span class="input-group-text" id="currency" >###</span>
            </div>
          </div>
        <?php $__errorArgs = ['Amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    
 
    
    
</div>
    

<hr>

    <div class="row">
     
    
        <div class="form-group col-sm-auto">
            <label for="exampleFormControlInput">Staf Name</label>
            <input disabled type="text" class="form-control" id="exampleFormControlInput" name="Staf_Name" value="<?php echo e($staf_name); ?>">
            <?php $__errorArgs = ['Staf_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        


        
    </div>
    
    <hr>

    <input hidden type="text" name="Paid_Through" id="Paid_Through" value="">
    <input hidden type="text" name="Currency" id="currency_symb" value="">
    

                <div class="col-xs-12 col-sm-12 col-md-12 text-center">

                    <button type="submit" class="btn btn-outline-success mb-2">Save</button>
                    <button style="margin-left: 20px" type="reset" class="btn btn-outline-danger mb-2">Clear</button>
                
                </div>
</form>



<script>
    function setBank(){
               var curr2 = document.getElementById("bank").value;
               document.getElementById("currency").innerHTML = document.getElementById(curr2).value;
               document.getElementById("currency_symb").value = document.getElementById(curr2).value;

               setBank_id();
               
    }

    function setBank_id(){
               var curr2 = document.getElementById("bank").value;
               var character = "2";
               var bankid = curr2+character;
               document.getElementById("Paid_Through").value = document.getElementById(bankid).value; 

    }

           

</script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/bedscect/ops.bedsconnect.com/resources/views/admin/expense/create.blade.php ENDPATH**/ ?>