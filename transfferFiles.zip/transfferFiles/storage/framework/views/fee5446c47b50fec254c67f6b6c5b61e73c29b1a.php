<!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
<script src="<?php echo e(asset('assets/js/libs/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>

<?php if($page_name != 'coming_soon' && $page_name != 'contact_us' && $page_name != 'error404' && $page_name != 'error500' && $page_name != 'error503' && $page_name != 'faq' && $page_name != 'helpdesk' && $page_name != 'maintenence' && $page_name != 'privacy' && $page_name != 'auth_boxed' && $page_name != 'auth_default'): ?>
<script src="<?php echo e(asset('plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<script>
    $(document).ready(function() {
        App.init();
    });
</script>
<script src="<?php echo e(asset('assets/js/scrollspyNav.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/highlight/highlight.pack.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php endif; ?>
<!-- END GLOBAL MANDATORY SCRIPTS -->

<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->
<?php switch($page_name):
    case ('sales'): ?>
      
      <script src="<?php echo e(asset('plugins/apex/apexcharts.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/dashboard/dash_1.js')); ?>"></script>
      <?php break; ?>

    <?php case ('analytics'): ?>
      
      <script src="<?php echo e(asset('plugins/apex/apexcharts.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/dashboard/dash_2.js')); ?>"></script>
      <?php break; ?>

    <?php case ('reservation'): ?>
    
    <script src="<?php echo e(asset('plugins/table/datatable/datatables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/apps/ts.js')); ?>"></script>
    <script>
        // var e;
        c1 = $('#style-1').DataTable({
            headerCallback:function(e, a, t, n, s) {
                e.getElementsByTagName("th")[0].innerHTML='<label class="new-control new-checkbox checkbox-outline-info m-auto">\n<input type="checkbox" class="new-control-input chk-parent select-customers-info" id="customer-all-info">\n<span class="new-control-indicator"></span><span style="visibility:hidden">c</span>\n</label>'
            },
            columnDefs:[ {
                targets:0, width:"30px", className:"chk", orderable:false, render:function(e, a, t, n) {
                    return'<label class="new-control new-checkbox checkbox-outline-info  m-auto">\n<input type="checkbox" class="new-control-input child-chk select-customers-info" id="customer-all-info">\n<span class="new-control-indicator"></span><span style="visibility:hidden">c</span>\n</label>'
                }
               
            }],
            "dom": "<'dt--top-section'<'row'<'col-12 col-sm-6 d-flex justify-content-sm-start justify-content-center'l><'col-12 col-sm-6 d-flex justify-content-sm-end justify-content-center mt-sm-0 mt-3'f>>>" +
        "<'table-responsive'tr>" +
        "<'dt--bottom-section d-sm-flex justify-content-sm-between text-center'<'dt--pages-count  mb-sm-0 mb-3'i><'dt--pagination'p>>",
            "oLanguage": {
                "oPaginate": { "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>', "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>' },
                "sInfo": "Showing page _PAGE_ of _PAGES_",
                "sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
                "sSearchPlaceholder": "Search...",
               "sLengthMenu": "Results :  _MENU_",
            },
            "lengthMenu": [10, 50, 100, 250],
            "pageLength": 500 
        });
          

        multiCheck(c1);

    </script>
    
    <?php break; ?>
    
    <?php case ('general_contact'): ?>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/theme-checkbox-radio.css')); ?>">
      <link href="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('assets/css/apps/contacts.css')); ?>" rel="stylesheet" type="text/css" />
      <script src="<?php echo e(asset('assets/js/apps/contact.js')); ?>"></script>
      <?php break; ?>
    
    <?php case ('sellers_contact'): ?>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/theme-checkbox-radio.css')); ?>">
      <link href="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('assets/css/apps/contacts.css')); ?>" rel="stylesheet" type="text/css" />
      <?php break; ?>
    
    <?php case ('buyers_contact'): ?>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/theme-checkbox-radio.css')); ?>">
      <link href="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('assets/css/apps/contacts.css')); ?>" rel="stylesheet" type="text/css" />
      <?php break; ?>
   
    <?php case ('expense'): ?>
      <script src="<?php echo e(asset('plugins/apex/apexcharts.min.js')); ?>"></script>
      <script src="<?php echo e(asset('plugins/apex/custom-apexcharts.js')); ?>"></script>  
      <script src="<?php echo e(asset('assets/js/dashboard/dash_1.js')); ?>"></script>
      <?php break; ?>
      
    <?php case ('mailbox'): ?>    
      <script src="<?php echo e(asset('assets/js/ie11fix/fn.fix-padStart.js')); ?>"></script>
      <script src="<?php echo e(asset('plugins/editors/quill/quill.js')); ?>"></script>
      <script src="<?php echo e(asset('plugins/sweetalerts/sweetalert2.min.js')); ?>"></script>
      <script src="<?php echo e(asset('plugins/notification/snackbar/snackbar.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/apps/custom-mailbox.js')); ?>"></script>
      <?php break; ?>
    
    <?php case ('bank'): ?>
      <script src="<?php echo e(asset('plugins/apex/apexcharts.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/widgets/modules-widgets.js')); ?>"></script>
      <script src="<?php echo e(asset('plugins/apex/custom-apexcharts.js')); ?>"></script>  
      <script src="<?php echo e(asset('assets/js/dashboard/dash_1.js')); ?>"></script>
      <?php break; ?>
    
  
    
    
    
  <?php default: ?>
    <script>console.log('No custom script available.')</script>
<?php endswitch; ?>
<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS --><?php /**PATH C:\xampp\htdocs\project1\resources\views/inc/scripts.blade.php ENDPATH**/ ?>