

<?php $__env->startSection('content'); ?>

            <div class="layout-px-spacing">

                

                <div class="row sales layout-top-spacing">
                   
                <div id="chartArea" class="col-xl-12 layout-spacing">
                    <div class="statbox widget box box-shadow">
                        <div class="widget-header">                                
                            <div class="row">
                                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                    <h4>Simple Area</h4> 
                                </div>
                            </div>
                        </div>
                        <div class="widget-content widget-content-area">
                            <div id="s-line-area" class=""></div>

                            
                        </div>
                    </div>
                
                </div>

                    
                    <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
                        <div class="widget widget-table-two">

                            <div class="widget-heading">
                                <h5 class="">Recent Orders</h5>
                            </div>

                            <div class="widget-content">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th><div class="th-content">Customer</div></th>
                                                <th><div class="th-content">Product</div></th>
                                                <th><div class="th-content">Invoice</div></th>
                                                <th><div class="th-content th-heading">Price</div></th>
                                                <th><div class="th-content">Status</div></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><div class="td-content customer-name"><img src="<?php echo e(asset('storage/img/90x90.jpg')); ?>" alt="avatar">Andy King</div></td>
                                                <td><div class="td-content product-brand">Nike Sport</div></td>
                                                <td><div class="td-content">#76894</div></td>
                                                <td><div class="td-content pricing"><span class="">$88.00</span></div></td>
                                                <td><div class="td-content"><span class="badge outline-badge-primary">Shipped</span></div></td>
                                            </tr>
                                            <tr>
                                                <td><div class="td-content customer-name"><img src="<?php echo e(asset('storage/img/90x90.jpg')); ?>" alt="avatar">Irene Collins</div></td>
                                                <td><div class="td-content product-brand">Speakers</div></td>
                                                <td><div class="td-content">#75844</div></td>
                                                <td><div class="td-content pricing"><span class="">$84.00</span></div></td>
                                                <td><div class="td-content"><span class="badge outline-badge-success">Paid</span></div></td>
                                            </tr>
                                            <tr>
                                                <td><div class="td-content customer-name"><img src="<?php echo e(asset('storage/img/90x90.jpg')); ?>" alt="avatar">Laurie Fox</div></td>
                                                <td><div class="td-content product-brand">Camera</div></td>
                                                <td><div class="td-content">#66894</div></td>
                                                <td><div class="td-content pricing"><span class="">$126.04</span></div></td>
                                                <td><div class="td-content"><span class="badge outline-badge-danger">Pending</span></div></td>
                                            </tr>
                                            <tr>
                                                <td><div class="td-content customer-name"><img src="<?php echo e(asset('storage/img/90x90.jpg')); ?>" alt="avatar">Luke Ivory</div></td>
                                                <td><div class="td-content product-brand">Headphone</div></td>
                                                <td><div class="td-content">#46894</div></td>
                                                <td><div class="td-content pricing"><span class="">$56.07</span></div></td>
                                                <td><div class="td-content"><span class="badge outline-badge-success">Paid</span></div></td>
                                            </tr>
                                            <tr>
                                                <td><div class="td-content customer-name"><img src="<?php echo e(asset('storage/img/90x90.jpg')); ?>" alt="avatar">Ryan Collins</div></td>
                                                <td><div class="td-content product-brand">Sport</div></td>
                                                <td><div class="td-content">#89891</div></td>
                                                <td><div class="td-content pricing"><span class="">$108.09</span></div></td>
                                                <td><div class="td-content"><span class="badge outline-badge-primary">Shipped</span></div></td>
                                            </tr>
                                            <tr>
                                                <td><div class="td-content customer-name"><img src="<?php echo e(asset('storage/img/90x90.jpg')); ?>" alt="avatar">Nia Hillyer</div></td>
                                                <td><div class="td-content product-brand">Sunglasses</div></td>
                                                <td><div class="td-content">#26974</div></td>
                                                <td><div class="td-content pricing"><span class="">$168.09</span></div></td>
                                                <td><div class="td-content"><span class="badge outline-badge-primary">Shipped</span></div></td>
                                            </tr>
                                            <tr>
                                                <td><div class="td-content customer-name"><img src="<?php echo e(asset('storage/img/90x90.jpg')); ?>" alt="avatar">Sonia Shaw</div></td>
                                                <td><div class="td-content product-brand">Watch</div></td>
                                                <td><div class="td-content">#76844</div></td>
                                                <td><div class="td-content pricing"><span class="">$110.00</span></div></td>
                                                <td><div class="td-content"><span class="badge outline-badge-success">Paid</span></div></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 col-12 layout-spacing">    
                        
                        <div class="widget widget-account-invoice-one">

                            <div class="widget-heading">
                                <h5 class="">Account Info</h5>
                            </div>

                            <div class="widget-content">
                                <div class="invoice-box">
                                    
                                    <div class="acc-total-info">
                                        <h5>Balance</h5>
                                        <p class="acc-amount">$470</p>
                                    </div>

                                    <div class="inv-detail">                                        
                                        <div class="info-detail-1">
                                            <p>Monthly Plan</p>
                                            <p>$ 199.0</p>
                                        </div>
                                        <div class="info-detail-2">
                                            <p>Taxes</p>
                                            <p>$ 17.82</p>
                                        </div>
                                        <div class="info-detail-3 info-sub">
                                            <div class="info-detail">
                                                <p>Extras this month</p>
                                                <p>$ -0.68</p>
                                            </div>
                                            <div class="info-detail-sub">
                                                <p>Netflix Yearly Subscription</p>
                                                <p>$ 0</p>
                                            </div>
                                            <div class="info-detail-sub">
                                                <p>Others</p>
                                                <p>$ -0.68</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="inv-action">
                                        <a href="" class="btn btn-dark">Summary</a>
                                        <a href="" class="btn btn-danger">Transfer</a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    


                </div>



            </div>
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/bedscect/ops.bedsconnect.com/resources/views/pages/bank/B_A_1.blade.php ENDPATH**/ ?>