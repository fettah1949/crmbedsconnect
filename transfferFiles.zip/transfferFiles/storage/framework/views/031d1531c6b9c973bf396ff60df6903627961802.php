<link href="<?php echo e(asset('assets/css/loader.css')); ?>" rel="stylesheet" type="text/css" />
<script src="<?php echo e(asset('assets/js/loader.js')); ?>"></script>

<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
<link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />

<?php if($page_name != 'coming_soon' && $page_name != 'contact_us' && $page_name != 'error404' && $page_name != 'error500' && $page_name != 'error503' && $page_name != 'faq' && $page_name != 'helpdesk' && $page_name != 'maintenence' && $page_name != 'privacy' && $page_name != 'auth_boxed' && $page_name != 'auth_default'): ?>
<link href="<?php echo e(asset('assets/css/plugins.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/css/scrollspyNav.css')); ?>" rel="stylesheet" type="text/css" />
<?php endif; ?>
<!-- END GLOBAL MANDATORY STYLES -->

<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<?php switch($page_name):
    case ('analytics'): ?>
      
      <link href="<?php echo e(asset('plugins/apex/apexcharts.css')); ?>" rel="stylesheet" type="text/css">
      <link href="<?php echo e(asset('assets/css/dashboard/dash_2.css')); ?>" rel="stylesheet" type="text/css" />
      <?php break; ?>

    <?php case ('sales'): ?>
      
      <link href="<?php echo e(asset('plugins/apex/apexcharts.css')); ?>" rel="stylesheet" type="text/css">
      <link href="<?php echo e(asset('assets/css/dashboard/dash_1.css')); ?>" rel="stylesheet" type="text/css" />
      <?php break; ?>

    <?php case ('reservation'): ?>
      
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/dt.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/theme-checkbox-radio.css')); ?>">
      <link href="<?php echo e(asset('assets/css/components/custom-modal.css')); ?>" rel="stylesheet" type="text/css" />  
      

      <?php break; ?>

    <?php case ('general_contact'): ?>
      <script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/apps/contact.js')); ?>"></script>
      <?php break; ?>

    <?php case ('sellers_contact'): ?>
      <script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/apps/contact.js')); ?>"></script>
      <?php break; ?>

    <?php case ('buyers_contact'): ?>
      <script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/apps/contact.js')); ?>"></script>
      <?php break; ?>

    <?php case ('expense'): ?>
      
      <link href="<?php echo e(asset('assets/css/scrollspyNav.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('plugins/apex/apexcharts.css')); ?>" rel="stylesheet" type="text/css"/>
      <link href="<?php echo e(asset('assets/css/dashboard/dash_2.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('assets/css/dashboard/dash_1.css')); ?>" rel="stylesheet" type="text/css" />
      <style>
          .apexcharts-canvas {
              margin: 0 auto;
          }

          .apexcharts-title-text {
              fill: #e0e6ed;
          }
          .apexcharts-yaxis-label {
              fill: #e0e6ed;
          }
          .apexcharts-xaxis-label {
              fill: #e0e6ed;
          }
          .apexcharts-legend-text {
              color: #e0e6ed!important;
          }
          .apexcharts-radialbar-track.apexcharts-track .apexcharts-radialbar-area {
              stroke: #191e3a;
          }
          .apexcharts-pie-label, .apexcharts-datalabel, .apexcharts-datalabel-label, .apexcharts-datalabel-value {
              fill: #bfc9d4;
          }
      </style>
      <?php break; ?>

    <?php case ('mailbox'): ?>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/editors/quill/quill.snow.css')); ?>">
      <link href="<?php echo e(asset('assets/css/apps/mailbox.css')); ?>" rel="stylesheet" type="text/css" />
      <script src="plugins/sweetalerts/promise-polyfill.js"></script>
      <link href="<?php echo e(asset('plugins/sweetalerts/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('plugins/sweetalerts/sweetalert.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('plugins/notification/snackbar/snackbar.min.css')); ?>" rel="stylesheet" type="text/css" />
      <?php break; ?>

    <?php case ('bank'): ?>
      
      <link href="<?php echo e(asset('plugins/apex/apexcharts.css')); ?>" rel="stylesheet" type="text/css">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/widgets/modules-widgets.css')); ?>">
      <link href="<?php echo e(asset('assets/css/scrollspyNav.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('assets/css/dashboard/dash_2.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('assets/css/dashboard/dash_1.css')); ?>" rel="stylesheet" type="text/css" />
      <?php break; ?>
    
    
    <?php default: ?>
        <script>console.log('No custom Styles available.')</script>
<?php endswitch; ?>
<!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES --><?php /**PATH C:\xampp\htdocs\project1\resources\views/inc/styles.blade.php ENDPATH**/ ?>