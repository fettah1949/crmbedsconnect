<?php

    $category_name = 'finance';
    $page_name = 'banks';
    $has_scrollspy = 0;
    $scrollspy_offset = '';

    

?>


   
<?php $__env->startSection('content'); ?>


<?php if( $transaction->Type === 'TRANSACTION'): ?>


<br>

<nav class="breadcrumb-two" aria-label="breadcrumb">
    <ol style="background: none" class="breadcrumb">
        <li class="breadcrumb-item active"><a href="<?php echo e(route('bank_transactions',$bank->id)); ?> ">Transaction List</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">Edit Transaction : <?php echo e($transaction->Reference_Number); ?></a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">Bank Name : <?php echo e($bank->Nom_du_compte); ?> | Bank N° : <?php echo e($bank->Numero_de_compte); ?></a></li>
    </ol>

</nav>
 
<hr>
   
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
   
    
    
    
    <form action="<?php echo e(route('transactions.update',$transaction->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row">
            
            
            
            
            <input hidden type="text" name="Transaction_id" value="<?php echo e($transaction->id); ?>">
            <input hidden type="text" name="Bank_id" value="<?php echo e($bank->id); ?>">
            
            
                       <div class="form-group col-sm-auto">
                           <label for="exampleFormControlInput">Date</label>
                           <input type="date" class="form-control" id="exampleFormControlInput" name="Date" placeholder="date" value="<?php echo e($transaction->Date); ?>">
                           <?php $__errorArgs = ['Date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       </div>
            
                       <div class="form-group">
                           <label for="exampleFormControlInput">Description</label>
                           <input type="text" class="form-control" id="exampleFormControlInput" name="Description" placeholder="Description" value="<?php echo e($transaction->Description); ?>">
                           <?php $__errorArgs = ['Description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <hr>
                    
                    
                    <div class="row">
                        
                        <div class="form-group col-sm-auto">
                            <label>Type :<span style="color: red">*</span></label>
                                <?php if($transaction->Credit > 0): ?>

                                <input disabled class="form-control" value="CREDIT" >
                                <input hidden class="form-control" value="CREDIT" name="transaction_type" >

                                <?php elseif($transaction->Debit > 0): ?>

                                <input disabled class="form-control" value="DEBIT" >
                                <input hidden class="form-control" value="DEBIT" name="transaction_type" >

                                <?php endif; ?>
    
                            </select>
                            <?php $__errorArgs = ['transaction_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group col-sm-auto">
                            <label for="Amount">Amount <?php echo e($bank->Devise); ?><span style="color: red">*</span></label>
                            <?php if($transaction->Credit > 0): ?>
                            <input type="decimal" class="form-control" id="Amount" placeholder="0.00" name="Amount" value="<?php echo e($transaction->Credit); ?>">
                            <?php elseif($transaction->Debit > 0): ?>
                            <input type="decimal" class="form-control" id="Amount" placeholder="0.00" name="Amount" value="<?php echo e($transaction->Debit); ?>">
                            <?php endif; ?>
                            <?php $__errorArgs = ['Amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group col-sm-auto">
                            <label for="exampleFormControlInput">Payee</label>
                            <input type="text" class="form-control" id="exampleFormControlInput" name="Payee" placeholder="Payee" value="<?php echo e($transaction->Payee); ?>">
                            <?php $__errorArgs = ['Payee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                    
                    
                    
                </div>
                
                <hr>

                <div class="col-xs-12 col-sm-12 col-md-12 text-center">

                    <button type="submit" class="btn btn-outline-success mb-2">Save</button>
                    <button style="margin-left: 20px" type="reset" class="btn btn-outline-danger mb-2">Clear</button>
                
                </div>
</form>



<?php endif; ?>







<?php if( $transaction->Type === 'TRANSFER'): ?>

<br>

<?php
    dd("here we are in Transfer Section");
?>

<nav class="breadcrumb-two" aria-label="breadcrumb">
    <ol style="background: none" class="breadcrumb">
        <li class="breadcrumb-item active"><a href="<?php echo e(route('banks.index')); ?>">Transaction List</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">New Transfer From</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">Bank Name : <?php echo e($bank->Nom_du_compte); ?> | Bank N° : <?php echo e($bank->Numero_de_compte); ?></a></li>
    </ol>
</nav>
 
<hr>
   
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
   



<form action="<?php echo e(route('transactions.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
  
    <div class="row">
        
        
            
        <input hidden type="text" name="type" value="<?php echo e($type); ?>">
        <input hidden type="text" name="Bank_id" value="<?php echo e($bank->id); ?>">
        <input hidden type="text" name="Bank2_id" id="bank2_id" value="">
        
        
        
        <div class="form-group col-sm-auto">
                        <label for="exampleFormControlInput">Reference_Number<span style="color: red">*</span></label>
                        <input type="text" class="form-control" id="exampleFormControlInput" name="Reference_Number" placeholder="Reference_Number">
                        <?php $__errorArgs = ['Reference_Number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
            
                   <div class="form-group col-sm-auto">
                       <label for="exampleFormControlInput">Date</label>
                       <input type="date" class="form-control" id="exampleFormControlInput" name="Date" placeholder="date">
                       <?php $__errorArgs = ['Date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </div>
        
                   <div class="form-group">
                       <label for="exampleFormControlInput">Description</label>
                       <input type="text" class="form-control" id="exampleFormControlInput" name="Description" placeholder="Description">
                       <?php $__errorArgs = ['Description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                
                <hr>
                
                
                <div class="row">
                    
                    
                    
                  <div class="form-group col-sm-auto">
                      <label for="amount1">Amount Debit<span style="color: red">*</span></label>
                      <div class="input-group mb-4">
                          <input type="number" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" id="amount1" placeholder="0.00" name="Amount1">
                          <div class="input-group-prepend">
                            <span class="input-group-text" id="inputGroup-sizing-default"><?php echo e($currency); ?></span>
                          </div>
                        </div>
                      <?php $__errorArgs = ['Amount1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                                        


                    <div class="form-group col-sm-auto">
                        <label for="exampleFormControlInput">Transfer To :</label>
                    
                        <input class="form-control" id="bank2" placeholder="Select Bank" name="Bank2" type="text" list="select-bank" onkeyup='setBank2();'>
                         <datalist id="select-bank">
                         
                            <option value="">Select Bank</option>
                             <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <input hidden type="text" id="<?php echo e($bank->Nom_du_compte); ?>2" value="<?php echo e($bank->id); ?>">
                             <input hidden type="text" id="<?php echo e($bank->Nom_du_compte); ?>" value="<?php echo e($bank->Devise); ?>">
                             <option value="<?php echo e($bank->Nom_du_compte); ?>"><?php echo e($bank->Nom_du_compte); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </datalist>  
                        <?php $__errorArgs = ['Bank2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="form-group col-sm-auto">
                        <label for="exchange">Exchange :<span style="color: red">*</span></label>
                        <input type="decimal" class="form-control" id="exchange" value="1.00" onchange='setAmount2();'>
                    </div>

                    <div class="form-group col-sm-auto">
                        <label for="amount2">Amount Credit</label>


                        <div class="input-group mb-4">
                            <input type="number" class="form-control" aria-label="Default" aria-describedby="currency2" id="amount2" placeholder="0.00" name="Amount2">
                            <div class="input-group-prepend">
                              <span class="input-group-text" id="currency2" >###</span>
                            </div>
                          </div>
                        <?php $__errorArgs = ['Amount2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                 
                
                
                
            </div>
            
            <hr>

                <div class="col-xs-12 col-sm-12 col-md-12 text-center">

                    <button type="submit" class="btn btn-outline-success mb-2">Save</button>
                    <button style="margin-left: 20px" type="reset" class="btn btn-outline-danger mb-2">Clear</button>
                
                </div>
</form>


<script>
    function setBank2(){
               var curr2 = document.getElementById("bank2").value;
               document.getElementById("currency2").innerHTML = document.getElementById(curr2).value;

               setBank2_id();
               
    }

    function setBank2_id(){
               var curr2 = document.getElementById("bank2").value;
               var character = "2";
               var bank2id = curr2+character;
               document.getElementById("bank2_id").value = document.getElementById(bank2id).value; 
               setAmount2();

    }

               function setAmount2(){
                   
                    document.getElementById("amount2").value = document.getElementById("amount1").value * document.getElementById("exchange").value ; 
            

        }

</script>

<?php endif; ?>



















<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/bedscect/ops.bedsconnect.com/resources/views/admin/banks/transactions/edit.blade.php ENDPATH**/ ?>