<?php
use App\Models\Bank;
$banks = Bank::all();

//dd($sellers);

    $category_name = 'finance';
    $page_name = 'banks';
    $has_scrollspy = 0;
    $scrollspy_offset = '';

    $currency = $bank->Devise;

  //  dd($bank);
?>

  
<?php $__env->startSection('content'); ?>

<?php if( $type === 'TRANSACTION'): ?>

<br>

<nav class="breadcrumb-two" aria-label="breadcrumb">
    <ol style="background: none" class="breadcrumb">
        <li class="breadcrumb-item active"><a href="<?php echo e(route('banks.index')); ?>">Transaction List</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">Add New Transaction</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">Bank Name : <?php echo e($bank->Nom_du_compte); ?> | Bank N° : <?php echo e($bank->Numero_de_compte); ?></a></li>
    </ol>

</nav>
 
<hr>
   
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
   
    
    
    
    <form action="<?php echo e(route('transactions.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="row">
            
            
            
            
            <input hidden type="text" name="type" value="<?php echo e($type); ?>">
            <input hidden type="text" name="Bank_id" value="<?php echo e($bank->id); ?>">
            
            
            
            <div class="form-group col-sm-auto">
                            <label for="exampleFormControlInput">Reference_Number<span style="color: red">*</span></label>
                            <input type="text" class="form-control" id="exampleFormControlInput" name="Reference_Number" placeholder="Reference_Number">
                            <?php $__errorArgs = ['Reference_Number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                
                       <div class="form-group col-sm-auto">
                           <label for="exampleFormControlInput">Date</label>
                           <input type="date" class="form-control" id="exampleFormControlInput" name="Date" placeholder="date">
                           <?php $__errorArgs = ['Date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       </div>
            
                       <div class="form-group">
                           <label for="exampleFormControlInput">Description</label>
                           <input type="text" class="form-control" id="exampleFormControlInput" name="Description" placeholder="Description">
                           <?php $__errorArgs = ['Description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <hr>
                    
                    
                    <div class="row">
                        
                        <div class="form-group col-sm-auto">
                            <label>Type :<span style="color: red">*</span></label>
                            <select class="form-control" id="exampleFormControlInput" name="transaction_type">
                                <option value="">Select Type</option>
                                <option value="DEBIT">Debit</option>
                                <option value="CREDIT">Credit</option>
                            </select>
                            <?php $__errorArgs = ['transaction_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-sm-auto">
                            <label for="exampleFormControlInput">Amount <?php echo e($currency); ?><span style="color: red">*</span></label>
                            <input type="decimal" class="form-control" id="exampleFormControlInput" placeholder="Amount" name="Amount">
                            <?php $__errorArgs = ['Amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="form-group col-sm-auto">
                            <label for="exampleFormControlInput">Payee</label>
                            <input type="text" class="form-control" id="exampleFormControlInput" name="Payee" placeholder="Payee">
                            <?php $__errorArgs = ['Payee'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                    
                    
                    
                </div>
                
                <hr>

                <div class="col-xs-12 col-sm-12 col-md-12 text-center">

                    <button type="submit" class="btn btn-outline-success mb-2">Save</button>
                    <button style="margin-left: 20px" type="reset" class="btn btn-outline-danger mb-2">Clear</button>
                
                </div>
</form>


<?php endif; ?>




<?php if( $type === 'TRANSFER'): ?>

<br>

<nav class="breadcrumb-two" aria-label="breadcrumb">
    <ol style="background: none" class="breadcrumb">
        <li class="breadcrumb-item active"><a href="<?php echo e(route('banks.index')); ?>">Transaction List</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">New Transfer From</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">Bank Name : <?php echo e($bank->Nom_du_compte); ?> | Bank N° : <?php echo e($bank->Numero_de_compte); ?></a></li>
    </ol>
</nav>
 
<hr>
   
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
   



<form action="<?php echo e(route('transactions.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
  
    <div class="row">
        
        
            
        <input hidden type="text" name="type" value="<?php echo e($type); ?>">
        <input hidden type="text" name="Bank_id" value="<?php echo e($bank->id); ?>">
        <input hidden type="text" name="Bank2_id" id="bank2_id" value="">
        
        
        
        <div class="form-group col-sm-auto">
                        <label for="exampleFormControlInput">Reference_Number<span style="color: red">*</span></label>
                        <input type="text" class="form-control" id="exampleFormControlInput" name="Reference_Number" placeholder="Reference_Number">
                        <?php $__errorArgs = ['Reference_Number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
            
                   <div class="form-group col-sm-auto">
                       <label for="exampleFormControlInput">Date</label>
                       <input type="date" class="form-control" id="exampleFormControlInput" name="Date" placeholder="date">
                       <?php $__errorArgs = ['Date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </div>
        
                   <div class="form-group">
                       <label for="exampleFormControlInput">Description</label>
                       <input type="text" class="form-control" id="exampleFormControlInput" name="Description" placeholder="Description">
                       <?php $__errorArgs = ['Description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                
                <hr>
                
                
                <div class="row">
                    
                    
                    
                  <div class="form-group col-sm-auto">
                      <label for="amount1">Amount Debit<span style="color: red">*</span></label>
                      <div class="input-group mb-4">
                          <input type="decimal" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" id="amount1" placeholder="0.00" name="Amount1">
                          <div class="input-group-prepend">
                            <span class="input-group-text" id="inputGroup-sizing-default"><?php echo e($currency); ?></span>
                          </div>
                        </div>
                      <?php $__errorArgs = ['Amount1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                                        


                    <div class="form-group col-sm-auto">
                        <label for="exampleFormControlInput">Transfer To :</label>
                    
                        <input class="form-control" id="bank2" placeholder="Select Bank" name="Bank2" type="text" list="select-bank" onkeyup='setBank2();'>
                         <datalist id="select-bank">
                         
                            <option value="">Select Bank</option>
                             <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php if( $value->id === $bank->id ): ?>
                             <?php else: ?>
                             <input hidden type="text" id="<?php echo e($value->Nom_du_compte); ?>2" value="<?php echo e($value->id); ?>">
                             <input hidden type="text" id="<?php echo e($value->Nom_du_compte); ?>" value="<?php echo e($value->Devise); ?>">
                             <option value="<?php echo e($value->Nom_du_compte); ?>"><?php echo e($value->Nom_du_compte); ?></option>
                             <?php endif; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </datalist>  
                        <?php $__errorArgs = ['Bank2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
              
                    <div class="form-group col-sm-auto">
                        <label for="exchange">Exchange :<span style="color: red">*</span></label>
                        <input type="decimal" class="form-control" id="exchange" value="1.00" onchange='setAmount2();'>
                    </div>

                    <div class="form-group col-sm-auto">
                        <label for="amount2">Amount Credit</label>


                        <div class="input-group mb-4">
                            <input type="decimal" class="form-control" aria-label="Default" aria-describedby="currency2" id="amount2" placeholder="0.00" name="Amount2">
                            <div class="input-group-prepend">
                              <span class="input-group-text" id="currency2" >###</span>
                            </div>
                          </div>
                        <?php $__errorArgs = ['Amount2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                 
                
                
                
            </div>
            
            <hr>

                <div class="col-xs-12 col-sm-12 col-md-12 text-center">

                    <button type="submit" class="btn btn-outline-success mb-2">Save</button>
                    <button style="margin-left: 20px" type="reset" class="btn btn-outline-danger mb-2">Clear</button>
                
                </div>
</form>


<script>
    function setBank2(){
               var curr2 = document.getElementById("bank2").value;
               document.getElementById("currency2").innerHTML = document.getElementById(curr2).value;

               setBank2_id();
               
    }

    function setBank2_id(){
               var curr2 = document.getElementById("bank2").value;
               var character = "2";
               var bank2id = curr2+character;
               document.getElementById("bank2_id").value = document.getElementById(bank2id).value; 
               setAmount2();

    }

               function setAmount2(){
                   
                    document.getElementById("amount2").value = document.getElementById("amount1").value * document.getElementById("exchange").value ; 
            

        }

</script>

<?php endif; ?>




<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/bedscect/ops.bedsconnect.com/resources/views/admin/banks/transactions/create.blade.php ENDPATH**/ ?>