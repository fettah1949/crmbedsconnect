

<?php $__env->startSection('content'); ?>
<div class="layout-px-spacing">
                
    <div class="row layout-top-spacing" id="cancel-row">
    
        <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
            <div class="widget-content widget-content-area br-6">
                <table id="zero-config" class="table table-hover" style="width:100%">
                    <thead>
                        <tr>
                            <th>Booking ID</th>
                            <th>Hotel</th>
                            <th>Costumer</th>
                            <th>Status</th>
                            <th>Booking Date</th>
                            <th>Check-In Date</th>
                            <th>Check-Out Date</th>
                            <th>Selling Price</th>
                            <th>Currency</th> 
                                
                        </tr>
                    </thead>
                    
                    <?php

                    $hostname = "localhost";
                    $username = "root";
                    $password = "";
                    $database_name = "test";

                    $connect = new mysqli($hostname,$username,$password,$database_name);
                    if ($connect->connect_error) {
                        die("Connection failed: " . $connect->connect_error);
                        }

                    $query = "SELECT * FROM reservation_table";
                    $result = $connect->query($query);
                    $query1 = "SELECT * FROM Hotel_list";
                    $result1 = $connect->query($query1);
                        ?>

                    <tbody>
                    <?php if ($result->num_rows > 0) {
                        // output data of each row
                            while($row = $result->fetch_assoc()) {
                                echo "<tr>                                   
                                <td>". $row["tgx"] ."</td>
                                <td>". $row["clientCode"] ."</td>
                                <td>". $row["mainGuestName"] ."</td>
                                <td class= \"text-center\"><span class=\"shadow-none badge badge-primary\">". $row["status"] ."</span></td>
                                <td>". $row["bookingDate"] ."</td>
                                <td>". $row["checkinDate"] ."</td>
                                <td>". $row["checkoutDate"] ."</td>
                                <td>". $row["sellingPrice_amount"] ."</td>
                                <td>". $row["sellingPrice_currency"] ."</td>
                                
                                
                                </tr>"

                    
                                    ;
                                }
                            } 
                            $connect->close();  
                        ?>
                    
                    </tbody>
                </table>
            </div>
        </div>

    </div>

</div>



<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project1\resources\views/table.blade.php ENDPATH**/ ?>