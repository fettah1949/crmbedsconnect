<?php

    $category_name = 'finance';
    $page_name = 'banks';
    $has_scrollspy = 0;
    $scrollspy_offset = '';

?>


   
<?php $__env->startSection('content'); ?>

<br>

<nav class="breadcrumb-two" aria-label="breadcrumb">
    <ol style="background: none" class="breadcrumb">
        <li class="breadcrumb-item active"><a href="<?php echo e(route('banks.index')); ?>">Bank List</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">Edit Bank: <?php echo e($banks->Nom_du_compte); ?></a></li>
    </ol>
</nav>
 
<hr>
   
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

        
    <form action="<?php echo e(route('banks.update',$banks->id)); ?>" method="POST" >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="row">

        <div class="form-group col-sm-auto">
            <label>Nom du compte</label>
            <input type="text" class="form-control"  placeholder="Nom du compte" name="Nom_du_compte" value="<?php echo e($banks->Nom_du_compte); ?>">
            <?php $__errorArgs = ['Nom_du_compte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
            <div class="form-group col-sm-auto">
                <label>Code du compte</label>
                <input type="text" class="form-control"  name="Code_du_compte" value="<?php echo e($banks->Code_du_compte); ?>" placeholder="Code du compte">
                <?php $__errorArgs = ['Code_du_compte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        
    
        <div class="form-group col-sm-auto">
            <label>Numero de compte</label>
            <input type="text" class="form-control"  name="Numero_de_compte" value="<?php echo e($banks->Numero_de_compte); ?>" placeholder="Numero de compte">
            <?php $__errorArgs = ['Numero_de_compte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group col-sm-auto">
            <label>Nom de la banque</label>
            <input type="text" class="form-control"  name="Nom_de_la_banque" value="<?php echo e($banks->Nom_de_la_banque); ?>" placeholder="Nom de la banque">
            <?php $__errorArgs = ['Nom_de_la_banque'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

    </div>
    
    <hr>


    <div class="row">
        <div class="form-group col-sm-auto">
            <label>SWIFT</label>
            <input type="text" class="form-control"  name="SWIFT" value="<?php echo e($banks->SWIFT); ?>" placeholder="SWIFT">
            <?php $__errorArgs = ['SWIFT'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label>Devise :</label>
            <select class="form-control" id="Devise" value="<?php echo e($banks->Devise); ?>" name="Devise">
            <option value="">Select Devise</option>
            <option value="EUR">EUR</option>
            <option value="MAD">MAD</option>
            <option value="USD">USD</option>
            </select>
            <?php $__errorArgs = ['Devise'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
             
    
        <div class="form-group col-sm-auto">
            <label>Balance</label>
            <input type="number" class="form-control"  name="Balance" value="<?php echo e($banks->Balance); ?>" placeholder="Balance">
            <?php $__errorArgs = ['Balance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    
        <div class="form-group col-sm-auto">
            <label>Description</label>
            <input type="text" class="form-control"  name="Description" value="<?php echo e($banks->Description); ?>" placeholder="Description">
            <?php $__errorArgs = ['Description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    
    <hr>



        <div class="col-xs-12 col-sm-12 col-md-12">
            <button type="submit" class="btn btn-outline-success mb-2">Update</button>
            <button style="margin-left: 10px" href="<?php echo e(route('banks.index')); ?>" class="btn btn-outline-dark mb-2">Cancel</button>
          </div>
 
      </form>
      <hr>

      <script type="text/javascript">
      
        document.getElementById("Devise").value = <?php echo json_encode($banks->Devise); ?>;    // set the value to this input 
      </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/bedscect/ops.bedsconnect.com/resources/views/admin/banks/edit.blade.php ENDPATH**/ ?>