<!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
<script src="<?php echo e(asset('assets/js/libs/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>

<?php if($page_name != 'coming_soon' && $page_name != 'contact_us' && $page_name != 'error404' && $page_name != 'error500' && $page_name != 'error503' && $page_name != 'faq' && $page_name != 'helpdesk' && $page_name != 'maintenence' && $page_name != 'privacy' && $page_name != 'auth_boxed' && $page_name != 'auth_default'): ?>
<script src="<?php echo e(asset('plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
<script>
    $(document).ready(function() {
        App.init();
    });
</script>
<script src="<?php echo e(asset('assets/js/scrollspyNav.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/highlight/highlight.pack.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php endif; ?>
<!-- END GLOBAL MANDATORY SCRIPTS -->

<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS -->
<?php switch($page_name):
    case ('sales'): ?>
      
      <script src="<?php echo e(asset('plugins/apex/apexcharts.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/dashboard/dash_1.js')); ?>"></script>
      <?php break; ?>

    <?php case ('analytics'): ?>
      
      <script src="<?php echo e(asset('plugins/apex/apexcharts.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/dashboard/dash_2.js')); ?>"></script>
      <?php break; ?>

      <?php case ('reservation'): ?>
      
      <script src="<?php echo e(asset('plugins/table/datatable/datatables.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/apps/ts.js')); ?>"></script>
     
      
      <?php break; ?>

      <?php case ('agencys'): ?>
      
      <script src="<?php echo e(asset('plugins/table/datatable/datatables.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/apps/ts.js')); ?>"></script>
     
      
      <?php break; ?>
    
      <?php case ('hotel_list'): ?>
      
      <script src="<?php echo e(asset('plugins/table/datatable/datatables.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/apps/ts.js')); ?>"></script>
     
      
      <?php break; ?>
    
    
      <?php case ('hotel_room_list'): ?>
      
      <script src="<?php echo e(asset('plugins/table/datatable/datatables.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/apps/ts.js')); ?>"></script>
     
      
      <?php break; ?>
    
    
      <?php case ('rooms_list'): ?>
      
      <script src="<?php echo e(asset('plugins/table/datatable/datatables.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/apps/ts.js')); ?>"></script>
     
      
      <?php break; ?>
      
      
      
    
      <?php case ('banks'): ?>

      <script src="<?php echo e(asset('plugins/apex/apexcharts.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/widgets/modules-widgets.js')); ?>"></script>
      <script src="<?php echo e(asset('plugins/apex/custom-apexcharts.js')); ?>"></script>  
      <script src="<?php echo e(asset('assets/js/dashboard/dash_1.js')); ?>"></script>

      
      <script src="<?php echo e(asset('plugins/table/datatable/datatables.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/apps/ts.js')); ?>"></script>
     
      
      <?php break; ?>
      
      
      <?php case ('transaction'): ?>

      <script src="<?php echo e(asset('plugins/apex/apexcharts.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/widgets/modules-widgets.js')); ?>"></script>
      <script src="<?php echo e(asset('plugins/apex/custom-apexcharts.js')); ?>"></script>  
      <script src="<?php echo e(asset('assets/js/dashboard/dash_1.js')); ?>"></script>

      
      <script src="<?php echo e(asset('plugins/table/datatable/datatables.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/apps/ts.js')); ?>"></script>
     
      
      <?php break; ?>
    
    
    
    <?php case ('general_contact'): ?>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/theme-checkbox-radio.css')); ?>">
      <link href="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('assets/css/apps/contacts.css')); ?>" rel="stylesheet" type="text/css" />
      <script src="<?php echo e(asset('assets/js/apps/contact.js')); ?>"></script>
      <?php break; ?>
    
    <?php case ('sellers_contact'): ?>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/theme-checkbox-radio.css')); ?>">
      <link href="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('assets/css/apps/contacts.css')); ?>" rel="stylesheet" type="text/css" />
      <?php break; ?>
    
    <?php case ('buyers_contact'): ?>
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/theme-checkbox-radio.css')); ?>">
      <link href="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('assets/css/apps/contacts.css')); ?>" rel="stylesheet" type="text/css" />
      <?php break; ?>
   
    <?php case ('expense'): ?>
    
    
      
      <script src="<?php echo e(asset('plugins/table/datatable/datatables.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/apps/ts.js')); ?>"></script>
     
      <script src="<?php echo e(asset('plugins/apex/apexcharts.min.js')); ?>"></script>
      <script src="<?php echo e(asset('plugins/apex/custom-apexcharts.js')); ?>"></script>  
      <script src="<?php echo e(asset('assets/js/dashboard/dash_1.js')); ?>"></script>
      <?php break; ?>
      
    <?php case ('mailbox'): ?>    
      <script src="<?php echo e(asset('assets/js/ie11fix/fn.fix-padStart.js')); ?>"></script>
      <script src="<?php echo e(asset('plugins/editors/quill/quill.js')); ?>"></script>
      <script src="<?php echo e(asset('plugins/sweetalerts/sweetalert2.min.js')); ?>"></script>
      <script src="<?php echo e(asset('plugins/notification/snackbar/snackbar.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/apps/custom-mailbox.js')); ?>"></script>
      <?php break; ?>
    
    <?php case ('bank'): ?>
      <script src="<?php echo e(asset('plugins/apex/apexcharts.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/widgets/modules-widgets.js')); ?>"></script>
      <script src="<?php echo e(asset('plugins/apex/custom-apexcharts.js')); ?>"></script>  
      <script src="<?php echo e(asset('assets/js/dashboard/dash_1.js')); ?>"></script>
      <?php break; ?>
    
  
    
    
    
  <?php default: ?>
    <script>console.log('No custom script available.')</script>
<?php endswitch; ?>
<!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM SCRIPTS --><?php /**PATH C:\xampp\htdocs\www\resources\views/inc/scripts.blade.php ENDPATH**/ ?>