<div class="modal fade" id="edit_reservation-<?php echo e($tgx); ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdrop"
aria-hidden="true">
<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="deleteModalLabel2">Reservation <?php echo e($tgx); ?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <i aria-hidden="true" class="ki ki-close"></i>
            </button>
        </div>
        <form action="<?php echo e(route('reservation.update',$tgx)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
        <div class="modal-body">
            <?php echo method_field('PUT'); ?>
            <div class="row">
                    
                    <div class="col-sm-6">
                        <div class="form-group col-sm-auto">
                            <label>Hotel Name</label>
                            <input disabled type="text" class="form-control" name="hotelName" value="<?php echo e($hotelName); ?>" title="<?php echo e($hotelName); ?>" placeholder="hotelName">
                            <?php $__errorArgs = ['hotelName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group col-sm-auto">
                            <label>Main Guest</label>
                            <input disabled type="text" class="form-control" name="mainGuestName" title="<?php echo e($mainGuestName); ?>" value="<?php echo e($mainGuestName); ?>" placeholder="mainGuestName">
                            <?php $__errorArgs = ['mainGuestName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                   
            </div> 
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group col-sm-auto">
                        <label>Provider</label>
                        <input disabled type="text" class="form-control" name="providerName" value="<?php echo e($providerName); ?>" title="<?php echo e($providerName); ?>" placeholder="providerName">
                        <?php $__errorArgs = ['providerName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            <div id="notif"></div>
            </div>
            <hr> 
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group col-sm-auto">
                        <label>Booking Date</label>
                        <input disabled type="text" class="form-control" name="bookingDate" value="<?php echo e($bookingDate); ?>" placeholder="bookingDate">
                        <?php $__errorArgs = ['bookingDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-sm-auto">
                        <label>Check in Date</label>
                        <input type="text" class="form-control" name="checkinDate" value="<?php echo e($checkinDate); ?>" placeholder="checkinDate">
                        <?php $__errorArgs = ['checkinDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group col-sm-auto">
                        <label>check out Date</label>
                        <input type="text" class="form-control" name="checkoutDate" value="<?php echo e($checkoutDate); ?>" placeholder="checkoutDate">
                        <?php $__errorArgs = ['checkoutDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-sm-auto">
                        <label>HCN_AC</label>
                        <input type="text" class="form-control" name="HCN_AC" value="<?php echo e($HCN_AC); ?>" placeholder="HCN_AC">
                        <?php $__errorArgs = ['HCN_AC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
              <div id="notif"></div>
           </div>
           <hr>
           <div class="row">
                <div class="col-sm-4">
                    <div class="form-group col-sm-auto">
                        <label>Status</label>
                        <select class="form-control" name="status" id="status">
                            <option value="">Select Status </option>
                            <option <?php if($status =="CN"): ?> selected <?php endif; ?> value="CN">Cancelled</option>
                            <option <?php if($status =="OK"): ?> selected <?php endif; ?> value="OK">Confirmed</option>
                            <option <?php if($status =="UN"): ?> selected <?php endif; ?> value="UN">Unknown Status</option>
                            <option <?php if($status =="CN-FEE"): ?> selected <?php endif; ?> value="CN-FEE">Cancelled Whith Fee</option>
                            <option <?php if($status =="CN-NRF"): ?> selected <?php endif; ?> value="CN-NRF">Cancelled Non Refundable</option>
                            <option <?php if($status =="NO-SHOW"): ?> selected <?php endif; ?> value="NO-SHOW">No-Show</option>
                        </select>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group col-sm-auto">
                        <label>Cancellation Date</label>
                        <input type="text" class="form-control" name="cancellationDate" value="<?php echo e($cancellationDate); ?>" placeholder="cancellationDate">
                        <?php $__errorArgs = ['cancellationDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
             
               <div class="col-sm-4">
                 <div class="form-group col-sm-auto">
                     <label>Cancellation Price</label>
                     <input type="text" class="form-control" name="cancellationPrice_amount" value="<?php echo e($cancellationPrice_amount); ?>" placeholder="cancellationPrice">
                     <?php $__errorArgs = ['cancellationPrice_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
    
                </div>
               
    
           </div>

           <hr>
    
            <div class="row">
                <?php
                $dt =  date("Y-m-d");
// $dt=                $dt->format('Y-m-d');
            ?>
                <div class="col-sm-4">
                    <div class="form-group col-sm-auto">
                        <input type="hidden" name="sellingPrice_currency" id="sellingPrice_currency" value="<?php echo e($sellingPrice_currency); ?>"  >
                        <label>Selling Price <span>:<?php echo e($sellingPrice_currency); ?></span></label>
                        <input type="text" class="form-control" id="sellingPrice_amount" name="sellingPrice_amount" value="<?php echo e($sellingPrice_amount); ?>"   placeholder="sellingPrice" onkeyup='setValue();'>
                        <?php $__errorArgs = ['sellingPrice_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group col-sm-auto">
                        <label>S.P.Exchange Rate</label>
                        <?php if($dt>= $checkoutDate): ?>
                        <input type="text" class="form-control" 
                        name="un_pr_selling_exchangeRate" id="un_pr_selling_exchangeRate" 
                        value="<?php echo e($quoteSelling_checkout); ?>"  onkeyup='setValue();'>
                        <?php else: ?>
                        <input type="text" class="form-control"  name="un_pr_selling_exchangeRate"
                         id="un_pr_selling_exchangeRate" 
                        value="<?php echo e($quoteSelling_booking); ?>"  onkeyup='setValue();' >
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group col-sm-auto">
                        <label>UN-Selling Price</label>
                      
                        <input type="text" class="form-control" name="un_pr_selling_EUR" 
                        id="un_pr_selling_EUR" placeholder="Selling EUR" value="<?php echo e($un_pr_selling_EUR); ?>"  onkeyup='setValue();'>
                       
                        <?php $__errorArgs = ['un_pr_selling_EUR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group col-sm-auto">
                        <input type="hidden" name="providerPrice_currency" value="<?php echo e($providerPrice_currency); ?>"  >
                        <label>Provider Price <span>:<?php echo e($providerPrice_currency); ?></span></label>
                        <input type="text" id="providerPrice_amount" class="form-control" name="providerPrice_amount" value="<?php echo e($providerPrice_amount); ?>"   placeholder="providerPrice" onkeyup='setValue();'>
                        <?php $__errorArgs = ['providerPrice_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
                <div class="col-sm-4">
                    <div class="form-group col-sm-auto">
                        <label>P.P.Exchange Rate</label>
                       
                        
                        <?php if($dt>= $checkoutDate): ?>
                     <input type="text" class="form-control" name="un_pr_purchasing_exchangeRate" 
                     id="un_pr_purchasing_exchangeRate"value="<?php echo e($quotePurchasing_checkout); ?>"   >
                        <?php else: ?>
                        <input type="text" class="form-control" name="un_pr_purchasing_exchangeRate" 
                     id="un_pr_purchasing_exchangeRate"value="<?php echo e($quotePurchasing_booking); ?>"   >
                        <?php endif; ?>
                    </div>
                    
                </div>
                <div class="col-sm-4">
                    <div class="form-group col-sm-auto">
                        <label>UN-Provider Price</label>
                        <input type="text" class="form-control" id="un_pr_purchasing_EUR" name="un_pr_purchasing_EUR" value="<?php echo e($un_pr_purchasing_EUR); ?>" placeholder="Provider EUR" onkeyup='setValue();'>
                        <?php $__errorArgs = ['un_pr_purchasing_EUR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
           </div>
           <hr>


           <div class="row">
            <div class="col-sm-3">
                   <div class="form-group col-sm-auto">
                       <label>Marge</label>
                       <input readonly id="marge" class="form-control" name="marge" value="<?php echo e($marge); ?>"   placeholder="Marge">
                   </div>
                </div>
                   <div class="col-sm-3">
                   <div class="form-group col-sm-auto">
                       <label for="Commission_bdsc">Comission BDSC</label>
   
   
                       <div class="input-group mb-4">
                           <input readonly class="form-control" aria-label="Default" aria-describedby="currency2" id="Commission_bdsc" name="Commission_bdsc" value="<?php echo e($Commission_bdsc * 100); ?>" placeholder="Commission_bdsc">
                           <div class="input-group-prepend">
                             <span class="input-group-text" id="currency2" >%</span>
                           </div>
                         </div>
                   </div>
                </div>
                   <div class="col-sm-3">
                   <div class="form-group col-sm-auto">
                       <label>Nights Count</label>
                       <input readonly class="form-control" id="nights_count" name="nights_count" value="<?php echo e($nights_count); ?>"  >
                   </div>
                </div>
                   <div class="col-sm-3">
                   <div class="form-group col-sm-auto">
                       <label>Price per Night</label>
                       <input readonly class="form-control" id="price_per_night" name="price_per_night" value="<?php echo e($price_per_night); ?>" placeholder="price_per_night">
                   </div>
                </div>
   
           </div>
        <div class="modal-footer">

            <button type="button" class="btn btn-danger" data-dismiss="modal">Fermer</button>
            <button type="submit" class="btn btn-success" id="copy">Enregistre</button>

        </div>
    </form>
    </div>
</div>
</div>
 <?php
// if($sellingPrice_currency == 'EUR'){
//         $diffrent = 1 ;
//     }elseif($sellingPrice_currency == 'USD'){
//         $diffrent = 0.8285690612312536249896428867;                                
//     }elseif($sellingPrice_currency == 'MAD'){
//         $diffrent = 0.0952380952380952380952380952 ;
//     }

//     if($providerPrice_currency == 'EUR'){
//         $diffrent2 = 1 ;
//     }elseif($providerPrice_currency == 'USD'){
//         $diffrent2 = 0.8285690612312536249896428867;                                
//     }elseif($providerPrice_currency == 'MAD'){
//         $diffrent2 = 0.0952380952380952380952380952 ;
//     }

?> 
<script type="text/javascript">


function setValue(){

    if(document.getElementById("providerPrice_amount").value > 0){

        document.getElementById("un_pr_selling_EUR").value = document.getElementById("sellingPrice_amount").value * document.getElementById("un_pr_selling_exchangeRate").value ;    // set the value to this input 
        document.getElementById("un_pr_purchasing_EUR").value = document.getElementById("providerPrice_amount").value * document.getElementById("un_pr_purchasing_exchangeRate").value ;    // set the value to this input 
        
        document.getElementById("marge").value = document.getElementById("un_pr_selling_EUR").value - document.getElementById("un_pr_purchasing_EUR").value;    // set the value to this input 
        var bdsc = (document.getElementById("un_pr_selling_EUR").value - document.getElementById("un_pr_purchasing_EUR").value)/document.getElementById("un_pr_purchasing_EUR").value;    // set the value to this input 
        document.getElementById("Commission_bdsc").value = (bdsc*100);
        
    } else {

        document.getElementById("un_pr_selling_EUR").value = document.getElementById("sellingPrice_amount").value * document.getElementById("un_pr_selling_exchangeRate").value ;    // set the value to this input 
        document.getElementById("un_pr_purchasing_EUR").value = document.getElementById("providerPrice_amount").value * document.getElementById("un_pr_purchasing_exchangeRate").value ;    // set the value to this input 
    

        document.getElementById("marge").value = 0 ;    // set the value to this input 
        document.getElementById("Commission_bdsc").value = 0;
        document.getElementById("price_per_night").value = 0;    // set the value to this input 

    }


}

              </script> <?php /**PATH C:\xampp\htdocs\bdseconnect\resources\views/reservation/pop_up/pop_up_edit_reservation.blade.php ENDPATH**/ ?>