
<?php

use App\Models\Country;
$countries = Country::all();

$category_name = 'contact';
$page_name = 'agencys';
$has_scrollspy = 0;
$scrollspy_offset = '';
?>

   
<?php $__env->startSection('content'); ?>
<br>

<nav class="breadcrumb-two" aria-label="breadcrumb">
    <ol style="background: none" class="breadcrumb">
        <li class="breadcrumb-item active"><a href="<?php echo e(route('agencylist.index')); ?>">Agency List</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">Edit Agency: <?php echo e($agencys->Agency_ID); ?> - Type: <?php echo e($agencys->Contact_Type); ?> </a></li>
    </ol>
</nav>
 

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
 
        
  
<form action="<?php echo e(route('agencylist.update',$agencys->id)); ?>" method="POST" >
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>


<div class="row">
<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Agency ID</label>
    <input disabled type="text" class="form-control" id="exampleFormControlInput" placeholder="Agency ID" value="<?php echo e($agencys->Agency_ID); ?>" name="Agency_ID">
    <?php $__errorArgs = ['Agency_ID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">VAT ID</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="VAT ID" value="<?php echo e($agencys->VAT_ID); ?>" name="VAT_ID">
    <?php $__errorArgs = ['VAT_ID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Agency Name</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Agency Name" value="<?php echo e($agencys->Agency_Name); ?>" name="Agency_Name">
    <?php $__errorArgs = ['Agency_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">First Name</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="First Name" value="<?php echo e($agencys->First_Name); ?>" name="First_Name">
    <?php $__errorArgs = ['First_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>
<hr>




<div class="row">
<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Last Name</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Last Name" value="<?php echo e($agencys->Last_Name); ?>" name="Last_Name">
    <?php $__errorArgs = ['Last_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Email</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Email" value="<?php echo e($agencys->Email); ?>" name="Email">
    <?php $__errorArgs = ['Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Email2</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Email2" value="<?php echo e($agencys->Email2); ?>" name="Email2">
    <?php $__errorArgs = ['Email2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Email3</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Email3" value="<?php echo e($agencys->Email3); ?>" name="Email3">
    <?php $__errorArgs = ['Email3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>
<hr>

 


<div class="row">
<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Phone</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Phone" value="<?php echo e($agencys->Phone); ?>" name="Phone">
    <?php $__errorArgs = ['Phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Mobile</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Mobile" value="<?php echo e($agencys->Mobile); ?>" name="Mobile">
    <?php $__errorArgs = ['Mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Emergency Phone</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Emergency Phone" value="<?php echo e($agencys->Emergency_Phone); ?>" name="Emergency_Phone">
    <?php $__errorArgs = ['Emergency_Phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Payment Terms</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Payment Terms" value="<?php echo e($agencys->Payment_Terms); ?>" name="Payment_Terms">
    <?php $__errorArgs = ['Payment_Terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>
<hr>

 


<div class="row">
<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Billing Address</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Billing Address" value="<?php echo e($agencys->Billing_Address); ?>" name="Billing_Address">
    <?php $__errorArgs = ['Billing_Address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Billing City</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Billing City" value="<?php echo e($agencys->Billing_City); ?>" name="Billing_City">
    <?php $__errorArgs = ['Billing_City'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Billing State</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Billing State" value="<?php echo e($agencys->Billing_State); ?>" name="Billing_State">
    <?php $__errorArgs = ['Billing_State'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Billing Country</label>

    <input class="form-control" name="Billing_Country" type="text" list="select-contry" placeholder="Select Country" value="<?php echo e($agencys->Billing_Country); ?>" >
     <datalist id="select-contry">
     
        <option value="">Select Country</option>
         <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <option value="<?php echo e($country->nom_en_gb); ?>"><?php echo e($country->nom_en_gb); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </datalist>  
    <?php $__errorArgs = ['Billing_Country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>
<hr>

 


<div class="row">
<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">ZIP code</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="ZIP code" value="<?php echo e($agencys->ZIP_code); ?>" name="ZIP_code">
    <?php $__errorArgs = ['ZIP_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Booking Manager</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Booking Manager" value="<?php echo e($agencys->Booking_Manager); ?>" name="Booking_Manager">
    <?php $__errorArgs = ['Booking_Manager'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Booking Manager email</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Booking Manager email" value="<?php echo e($agencys->Booking_Manager_email); ?>" name="Booking_Manager_email">
    <?php $__errorArgs = ['Booking_Manager_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Booking Manager Phone</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Booking Manager Phone" value="<?php echo e($agencys->Booking_Manager_Phone); ?>" name="Booking_Manager_Phone">
    <?php $__errorArgs = ['Booking_Manager_Phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>
<hr>

 


<div class="row">
<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Support Email</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Support Email" value="<?php echo e($agencys->Support_Email); ?>" name="Support_Email">
    <?php $__errorArgs = ['Support_Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Support Email 2</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Support Email 2" value="<?php echo e($agencys->Support_Email_2); ?>" name="Support_Email_2">
    <?php $__errorArgs = ['Support_Email_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Support Email 3</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Support Email 3" value="<?php echo e($agencys->Support_Email_3); ?>" name="Support_Email_3">
    <?php $__errorArgs = ['Support_Email_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Support Email 4</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Support Email 4" value="<?php echo e($agencys->Support_Email_4); ?>" name="Support_Email_4">
    <?php $__errorArgs = ['Support_Email_4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>
<hr>

 


<div class="row">
<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Financial Manager</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Financial Manager" value="<?php echo e($agencys->Financial_Manager); ?>" name="Financial_Manager">
    <?php $__errorArgs = ['Financial_Manager'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Financial Manager email</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Financial Manager email" value="<?php echo e($agencys->Financial_Manager_email); ?>" name="Financial_Manager_email">
    <?php $__errorArgs = ['Financial_Manager_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Financial Manager email2</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Financial Manager email2" value="<?php echo e($agencys->Financial_Manager_email2); ?>" name="Financial_Manager_email2">
    <?php $__errorArgs = ['Financial_Manager_email2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Financial Manager email3</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Financial Manager email3" value="<?php echo e($agencys->Financial_Manager_email3); ?>" name="Financial_Manager_email3">
    <?php $__errorArgs = ['Financial_Manager_email3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>
<hr>

 


<div class="row">
<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Financial Manager email4</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Financial Manager email4" value="<?php echo e($agencys->Financial_Manager_email4); ?>" name="Financial_Manager_email4">
    <?php $__errorArgs = ['Financial_Manager_email4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Financial Manager Phone</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Financial Manager Phone" value="<?php echo e($agencys->Financial_Manager_Phone); ?>" name="Financial_Manager_Phone">
    <?php $__errorArgs = ['Financial_Manager_Phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label for="exampleFormControlInput">Notes</label>
    <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Notes" value="<?php echo e($agencys->Notes); ?>" name="Notes">
    <?php $__errorArgs = ['Notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group col-sm-auto">
    <label>Contact Type</label>
    <select class="form-control" id="Contact_Type" value="<?php echo e($agencys->Contact_Type); ?>" name="Contact_Type">
    <option value="">Select Type</option>
    <option value="SELLER">Seller</option>
    <option value="BUYER">Buyer</option>
    <option value="HSS">HSS</option>
    </select>
    <?php $__errorArgs = ['Contact_Type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
</div>
<hr>


  
    

<div class="col-xs-12 col-sm-12 col-md-12">
    <button type="submit" class="btn btn-outline-success mb-2">Update</button>
    <a style="margin-left: 10px" href="<?php echo e(route('agencylist.index')); ?>" class="btn btn-outline-dark mb-2">Cancel</a>
  </div>

</form>
      <hr>

      <script type="text/javascript">
      
      document.getElementById("Contact_Type").value = <?php echo json_encode($agencys->Contact_Type); ?>;    // set the value to this input 
      document.getElementById("Billing_Country").value = <?php echo json_encode($agencys->Billing_Country); ?>;    // set the value to this input 
    </script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bdseconnect\resources\views/admin/agencys/edit.blade.php ENDPATH**/ ?>