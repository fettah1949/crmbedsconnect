<?php
    $category_name = 'finance';
    $page_name = 'banks';
    $has_scrollspy = 0;
    $scrollspy_offset = '';


$transaction = 'TRANSACTION';
$transfer = 'TRANSFER';
?>

<?php $__env->startSection('content'); ?>

<br>

<nav class="breadcrumb-two" aria-label="breadcrumb">
    <ol style="background: none" class="breadcrumb">
        <li class="breadcrumb-item active"><a href="<?php echo e(route('banks.index')); ?>">Bank List</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">Transactions of All Bank </a></li>
    </ol>
</nav>
 
<?php if(session()->get('success')): ?>
<div class="alert alert-success">
  <?php echo e(session()->get('success')); ?>  
</div>
<?php endif; ?>

<hr>

<div class="table-responsive">
    <table class="table table-striped mb-4" id="hotels-table">

        <thead>
        <tr>
            <th>.</th>
            <th>Date</th>
            <th>Debit</th>
            <th>Credit</th>
            <th>Payee</th>
            <th>Description </th>
            <th>Reference_Number</th>
            <th>Type</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <tr>

            <?php if(  $value->Debit  > 0): ?>
            <td style="background: rgba(255, 0, 0, 0.034)">-</td>
            <td style="background: rgba(255, 0, 0, 0.034)"><?php echo e($value->Date); ?></td>
            <td style="background: rgba(255, 0, 0, 0.034)"><?php echo e($value->Debit); ?></td>
            <td style="background: rgba(255, 0, 0, 0.034)"><?php echo e($value->Credit); ?></td>
            <td style="background: rgba(255, 0, 0, 0.034)"><?php echo e($value->Payee); ?></td>
            <td style="background: rgba(255, 0, 0, 0.034)"><?php echo e($value->Description); ?></td>
            <td style="background: rgba(255, 0, 0, 0.034)"><?php echo e($value->Reference_Number); ?></td>
            <td style="background: rgba(255, 0, 0, 0.034)"><?php echo e($value->Type); ?></td>
            <td style="background: rgba(255, 0, 0, 0.034)">


                
                <a  href="<?php echo e(route('bank_transactions',$value["Bank_id"])); ?>"   target="_blank"  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                </a>

            </td>

            <?php elseif(  $value->Credit  > 0): ?>
            <td style="background: rgba(9, 255, 0, 0.034)">-</td>
            <td style="background: rgba(9, 255, 0, 0.034)"><?php echo e($value->Date); ?></td>
            <td style="background: rgba(9, 255, 0, 0.034)"><?php echo e($value->Debit); ?></td>
            <td style="background: rgba(9, 255, 0, 0.034)"><?php echo e($value->Credit); ?></td>
            <td style="background: rgba(9, 255, 0, 0.034)"><?php echo e($value->Payee); ?></td>
            <td style="background: rgba(9, 255, 0, 0.034)"><?php echo e($value->Description); ?></td>
            <td style="background: rgba(9, 255, 0, 0.034)"><?php echo e($value->Reference_Number); ?></td>  
            <td style="background: rgba(9, 255, 0, 0.034)"><?php echo e($value->Type); ?></td>
    
            <td style="background: rgba(9, 255, 0, 0.034)">

                <a  href="<?php echo e(route('bank_transactions',$value["Bank_id"])); ?>"   target="_blank"  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                </a>

                </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<br>


</div>

      
<?php $__env->stopSection(); ?>

  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\resources\views/admin/banks/transactions/index.blade.php ENDPATH**/ ?>