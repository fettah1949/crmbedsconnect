<?php
function getBadge($var){
    switch($var){
        case "CN":
            return "badge-danger";
        case "OK":
            return "badge-success";
        case "CK":
            return "badge-secondary";
        case "KUN":
            return "badge-secondary";
        case "CN-FEE":
            return "badge-info";
        case "CN-NRF":
            return "badge-primary";
        case "NO-SHOW":
            return "badge-dark";

        // invoice status badge

        case "Invoiced":
            return "badge-success";
        case "Refund":
            return "badge-danger";
        case "Due":
            return "badge-secondary";
            

        // Payment status badge

        case "Payed":
            return "badge-success";
        case "Not-Payed":
            return "badge-danger";



    }
}

            $category_name = 'production';
            $page_name = 'reservation';
            $has_scrollspy = 0;
            $scrollspy_offset = '';

?>


 
<?php $__env->startSection('content'); ?>


<br>









<div class="widget-content widget-content-area br-6 text-center">
    
    <a type="button" style="margin: 5px" class="btn btn-outline-primary col-sm-full" >
        <h6>ADR</h6><hr style="margin-top: 5px; margin-bottom: 10px"> <span class="badge badge-pills badge-light"><?php echo e($res_state["state_nightprice"]); ?> Eur</span>
    </a>
    
    
    <a type="button" style="margin: 5px" class="btn btn-outline-info col-sm-full" >
        <h6>BDSC_Average</h6><hr style="margin-top: 5px; margin-bottom: 10px">  <span class="badge badge-pills badge-light"><?php echo e($res_state["state_bdsc"]); ?> %</span>
    </a>
    
    
    <a type="button" style="margin: 5px" class="btn btn-outline-success col-sm-full" >
        <h6>LOS</h6><hr style="margin-top: 5px; margin-bottom: 10px">  <span class="badge badge-pills badge-light"><?php echo e($res_state["state_nightcount"]); ?> Nights</span>
    </a>
                
 
         
                <a  type="button" style="margin: 5px" class="btn btn-outline-success col-sm-full" >
                 <h6>REVpar</h6><hr style="margin-top: 5px; margin-bottom: 10px">  <span class="badge badge-pills badge-light"><?php echo e($res_state["state_marge"]); ?> Eur</span>
                </a>
 
         
                <a   type="button" style="margin: 5px" class="btn btn-outline-info col-sm-full" >
                    <h6>Total_Nights</h6><hr style="margin-top: 5px; margin-bottom: 10px">  <span class="badge badge-pills badge-light"><?php echo e($res_state["tnight_count"]); ?> Nights</span>
                </a>
                
                
                
                    <div class="widget-content widget-content-area br-6 text-center" style="box-shadow: none;margin-top:-10">
                
                        <a   type="button" style="margin: 5px" class="btn btn-outline-primary col-sm-full" >
                            <h6>Turn_Over</h6> <hr style="margin-top: 5px; margin-bottom: 10px"> 
                            <span  class='shadow-none badge badge-success '><?php echo e($res_state["t_un_sell"]); ?>   €</span> <span style="margin-left:10px;"  class='shadow-none badge badge-danger'> <?php echo e($res_state["t_un_purshase"]); ?>   €</span>
                        </a>
                    
                    
                        <a   type="button" style="margin: 5px" class="btn btn-outline-primary col-sm-full" >
                            <h6>Total_Status</h6> <hr style="margin-top: 5px; margin-bottom: 10px"> 
                            <span  class='shadow-none badge badge-success '><?php echo e($res_state["res_ok"]); ?></span> <span style="margin-left:10px;"  class='shadow-none badge badge-danger'> <?php echo e($res_state["res_not_ok"]); ?></span>
                        </a>
                    
                        
                        <a   type="button" style="margin: 5px" class="btn btn-outline-success col-sm-full" >
                            <h6>Booking_Window</h6><hr style="margin-top: 5px; margin-bottom: 10px">  <span class="badge badge-pills badge-light"><?php echo e($res_state["state_bw"]); ?> Days</span>
                        </a>
                
                    </div>    
</div>
<br>




    <div class="widget-content widget-content-area br-6">


        <div  style="width: 100%" >
            <a  style="width: 100%"  href="#filter" data-active="false" data-toggle="collapse" aria-expanded="false" class="btn btn-outline-success mb-2">
                <div style="float: left;margin-left:10px">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    <span >Filter</span>
                </div>
            </a>
            <ul class="submenu list-unstyled collapse" id="filter" style="">
                
                    

                    
                <?php echo $__env->make('reservation.tab-filter',['filter'=>$filter], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                
            </ul>
        </div>
    </div>
            <?php if(session()->has('status')): ?>
                <div class="alert alert-custom alert-notice alert-outline-success fade show" role="alert">
                    <div class="alert-icon"><i class="flaticon-success"></i></div>
                    <div class="alert-text"> <?php echo e(session() ->get('status')); ?></div>
                    <div class="alert-close">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true"><i class="ki ki-close"></i></span>
                        </button>
                    </div>
                </div>
            <?php endif; ?>





     
                        
                        
                    
                        
                                        
                                        
                                        
                                            
                                        
                                        
                                        
                                        

                                        

                            


        
                                        
                                        
                                        
                                            
                                        
                                        
                                        
                                        

                                         
    

 

    <div class="main-container widget-content widget-content-area br-6" id="container">

        

    

        <!--  BEGIN CONTENT AREA  -->
        
            

                
                
                
                
                    
                        
                           
                            <table id="html5-extension" class="table" style="width:100%">
                                <thead>
                                    <tr>
                                        
                                        <th class="text-center " >Status</th>
                                            <th>Booking_ID</th>
                                            <th>BDC_ID</th>
                                            <th>Hotel</th> 
                                            <th>Client_ID</th>
                                            <th style="display:none">Provider_Name</th>
                                            <th style="display:none">Costumer</th>
                                            <th>HCN_AC</th>
                                            <th>Agency</th>
                                            <th class="mt ">Booking_Date</th>
                                            <th>Check_In_Date</th>
                                            <th>Check_Out_Date</th>
                                            <th>Selling_Price</th>
                                            <th>Marge</th>
                                            
                                            <th class="text-center dt-no-sorting" >Action</th>
                                                
                                        </tr>
                                </thead>
                                <tbody >
                              
                        
                             
                                    <?php $__currentLoopData = $Reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <tr class='res_tab' >
                                        
                                        <td class='text-center'><span class='shadow-none badge   '>

                                            <?php echo e($row["status"]); ?>

                                            <?php if($row["status"]=='CN'): ?>
                                            <div class="t-dot bg-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>
                                            <?php elseif($row["status"]=='OK'): ?>
                                            <div class="t-dot bg-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>
                                            <?php elseif($row["status"]=='CK'): ?>
                                            <div class="t-dot bg-secondary" data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>
                                            <?php elseif($row["status"]=='KUN'): ?>
                                            <div class="t-dot bg-secondary" data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>
                                            <?php elseif($row["status"]=='NO-SHOW'): ?>
                                            <div class="t-dot " data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>

                                            <?php endif; ?>


                                        
                                        </span></td>
                                        <td class='tgx' reservation-tgx = '<?php echo e($row["tgx"]); ?>' > <?php echo e($row["tgx"]); ?> </td>
                                        <td class='provider' reservation-provider = '<?php echo e($row["provider_h"]); ?>'><?php echo e($row["provider_h"]); ?></td>
                                        <td class='hotelCode' reservation-hotelCode = '<?php echo e($row["Hotel_Name"]); ?>'><?php echo e($row["Hotel_Name"]); ?></td>
                                        <td class='client' reservation-client = '<?php echo e($row["client"]); ?>'><?php echo e($row["client"]); ?></td>
                                        <td class='providerName' style="display:none" reservation-providerName = '<?php echo e($row["providerName"]); ?>'><?php echo e($row["providerName"]); ?></td>
                                        <td class='mainGuestName'  style="display:none" reservation-mainGuestName = '<?php echo e($row["mainGuestName"]); ?>'><?php echo e($row["mainGuestName"]); ?></td>
                                        <td ><?php echo e($row["HCN_AC"]); ?></td>
                                        <td class='clientCode' reservation-mainGuestName = '<?php echo e($row["clientCode"]); ?>'><?php echo e($row["clientCode"]); ?></td>
                                        <?php
                                        $bookingDate = explode(" ", $row["bookingDate"]);
                                        $checkinDate = explode(" ", $row["checkinDate"]);
                                        $checkoutDate = explode(" ", $row["checkoutDate"]);
                               
                                        ?>
                                        <td class='bookingDate' reservation-bookingDate = '<?php echo e(date('d-m-Y', strtotime($bookingDate[0]))); ?>'> <?php echo e(date('d-m-Y', strtotime($bookingDate[0]))); ?> <?php echo e(date('H:s', strtotime($bookingDate[1]))); ?></td>
                                        
                                        <td class='checkinDate' reservation-checkinDate = '<?php echo e($row["checkinDate"]); ?>'><?php echo e(date('d-m-Y', strtotime($checkinDate[0]))); ?></td>
                                        
                                        <td class='checkoutDate' reservation-checkoutDate = '<?php echo e($row["checkoutDate"]); ?>'><?php echo e(date('d-m-Y', strtotime($checkoutDate[0]))); ?></td>
                                        
                                        <td class='sellingPrice_amount' reservation-sellingPrice_amount = '<?php echo e($row["sellingPrice_amount"]); ?>'>
                                            <span style="float: left"><?php echo e($row["sellingPrice_amount"]); ?></span>
                                            <span style="float: left;margin-left:3px;"> 
                                                <?php if($row["sellingPrice_currency"] == 'EUR'): ?> 
                                                
                                                    €
                                                <?php elseif($row["sellingPrice_currency"] == 'USD'): ?>
                                                
                                                    $
                                                <?php endif; ?>
                                            
                                            </span>
                                        </td>
                                        
                                        <td class="text-center"><?php echo e($row["marge"]); ?> €</td>
                                        
                                       
                                        <td class='text-center'> 
                                            
                                            
                                            
                                                
                                            
                                            
                                            
                                            
                                            
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-dark btn-sm">Mail</button>
                                                <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuReference3">
                                                    <a class="dropdown-item" data-toggle="modal" data-target="#edit_reservation-<?php echo e($row["tgx"]); ?>" target="_blank">
                                                        Edit
                                                        <svg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-edit-2 p-1 br-6 mb-1'>
                                                        <path d='M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z'></path></svg></a>
                                                    
                                                        <a class="dropdown-item" data-toggle="modal" data-target="#update_innvoice-<?php echo e($row["tgx"]); ?>">
                                                        <?php echo e($row["Payment_Status"]); ?>

                                                        <?php if($row["Payment_Status"]=="Payed"): ?>
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="green" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-dollar-sign"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                                                        <?php else: ?>
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="red" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-dollar-sign"><line x1="12" y1="1" x2="12" y2="23"></line><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path></svg>
                                                        <?php endif; ?>
                                                    </a>
                                                    <div class="dropdown-divider"></div>
                                                    <a class="dropdown-item" href="#">
                                                        Note
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#1b55e2 " stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file-plus"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></svg>

                                                    </a>
                                                  
                                                    <a class="dropdown-item" href="#">
                                                        Send email
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#1b55e2 " stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-mail"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>                          

                                                    </a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php echo $__env->make('reservation.pop_up.pop_up_updateInnv',['tgx'=>$row["tgx"],'invoice_status_seller'=>$row["invoice_status_seller"],'invoice_status_buyer'=>$row["invoice_status_buyer"],'Payment_Status'=>$row["Payment_Status"]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('reservation.pop_up.pop_up_edit_reservation',['quoteSelling_checkout'=>$row["quoteSelling_checkout"],'quotePurchasing_checkout'=>$row["quotePurchasing_checkout"],'quoteSelling_booking'=>$row["quoteSelling_booking"],'quotePurchasing_booking'=>$row["quotePurchasing_booking"],'status'=>$row["status"],'marge'=>$row["marge"],'Commission_bdsc'=>$row["Commission_bdsc"],'nights_count'=>$row["nights_count"],'price_per_night'=>$row["price_per_night"],'providerPrice_currency'=>$row["providerPrice_currency"],'providerPrice_amount'=>$row["providerPrice_amount"],'un_pr_purchasing_EUR'=>$row["un_pr_purchasing_EUR"],'un_pr_selling_EUR'=>$row["un_pr_selling_EUR"],'sellingPrice_currency'=>$row["sellingPrice_currency"],'sellingPrice_amount'=>$row["sellingPrice_amount"],'reservation'=>$Reservations,'tgx'=>$row["tgx"],'hotelName'=>$row["hotelName"],'mainGuestName'=>$row["mainGuestName"],'providerName'=>$row["providerName"],'checkoutDate'=>$row["checkoutDate"],'bookingDate'=>$row["bookingDate"],'checkinDate'=>$row["checkinDate"],'HCN_AC'=>$row["HCN_AC"],'cancellationDate'=>$row["cancellationDate"],'cancellationPrice_amount'=>$row["cancellationPrice_amount"]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </tbody>
                            </table>

                        
                    

                

            
        
        <!--  END CONTENT AREA  -->
    </div>


    
<script type="text/javascript">
// function myFunction()
// {
//     // $("th").removeClass("sorting_asc");
//         alert('ff');
// }
// window.addEventListener('load', (event) => {
//     $("th").removeClass("sorting_asc");
//     $(".mt").addClass("sorting_desc");
// });
    // });
    function check_code()
    {
        //  alert($('#Code').val());
        if($('#Type_code').val()!="" && $('#Code').val()=="")
        {
            $('#code_message').text("merci d'ajouter le code");
            $('#Type_message').text("");
            $("#Code").prop('required',true);

        }
        if($('#Code').val()!="" && $('#Type_code').val()=="")
        {
            $('#code_message').text("");
            $('#Type_message').text("merci d'ajouter le Type de code")
            $("#Type_code").prop('required',true);
        }
        if($('#Code').val()=="" && $('#Type_code').val()=="" )
        {
            $("#Code").prop('required',false);
            $("#Type_code").prop('required',false);
            $('#code_message').text("");
            $('#Type_message').text("");
        }
        if($('#Code').val()!=""  )
        {
            $('#code_message').text("");
            

        }
        if($('#Type_code').val()!="" )
        {
            $('#Type_message').text("");
            

        }
    }
function vide()
{
    // $("#hotel").empty();
    $('#hotel').val(null).trigger('change');
    window.document.getElementById('hotel').selectedIndex = 0;

    $('#rangeCalendarFlatpickr').val(null).trigger('change');
    window.document.getElementById('rangeCalendarFlatpickr').selectedIndex = 0;

    $('#date_type').val(null).trigger('change');
    window.document.getElementById('date_type').selectedIndex = 0;

    $('#status').val(null).trigger('change');
    window.document.getElementById('status').selectedIndex = 0;

    $('#agency').val(null).trigger('change');
    window.document.getElementById('agency').selectedIndex = 0;

    $('#provider').val(null).trigger('change');
    window.document.getElementById('provider').selectedIndex = 0;

    $('#Payment_Status').val(null).trigger('change');
    window.document.getElementById('Payment_Status').selectedIndex = 0;

    $('#Type_code').val(null).trigger('change');
    window.document.getElementById('Type_code').selectedIndex = 0;

    $("#Code").val('');
    $('#Type_message').text("");
    $('#code_message').text("");
}
    // document.getElementById("start_date").value = <?php echo json_encode($filter["start_date"]); ?>;    // set the value to this input 
    // document.getElementById("end_date").value = <?php echo json_encode($filter["end_date"]); ?>;    // set the value to this input 
    // document.getElementById("rangeCalendarFlatpickr").value =  json_encode($filter["rangeCalendarFlatpickr"]);    // set the value to this input 
    // document.getElementById("date_type").value = <?php echo json_encode($filter["date_type"]); ?>;    // set the value to this input 
    // document.getElementById("status").value = <?php echo json_encode($filter["status"]); ?>;    // set the value to this input 
    //  document.getElementById("hotel").value = <?php echo json_encode(''); ?>;    // set the value to this input 
    // document.getElementById("agency").value = <?php echo json_encode($filter["agency"]); ?>;    // set the value to this input 
    // document.getElementById("provider").value = <?php echo json_encode($filter["provider"]); ?>;   // set the value to this input 
    // document.getElementById("Payment_Status").value = <?php echo json_encode($filter["Payment_Status"]); ?>;   // set the value to this input 

   

</script>


<?php $__env->stopSection(); ?>



          
   



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bdseconnect\resources\views/reservation/index.blade.php ENDPATH**/ ?>