<div class="modal fade" id="edit_agency-<?php echo e($id); ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdrop"
aria-hidden="true">
<div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="deleteModalLabel2">Edit Agency</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <i aria-hidden="true" class="ki ki-close"></i>
            </button>
        </div>


        <form action="<?php echo e(route('agencylist.update',$id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="tgx" value="<?php echo e($id); ?>" />
            <div class="modal-body">
                <?php echo method_field('PUT'); ?>
                <div class="row">

                        <div class="col-sm-6">
                            <div class="form-group col-sm-auto">
                                <label for="exampleFormControlInput">Agency ID</label>
                                <input disabled type="text" class="form-control" id="exampleFormControlInput" placeholder="Agency ID" value="<?php echo e($Agency_ID); ?>" name="Agency_ID">
                                <?php $__errorArgs = ['Agency_ID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                            
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group col-sm-auto">
                                <label for="exampleFormControlInput">Agency Name</label>
                                <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Agency Name" value="<?php echo e($Agency_Name); ?>" name="Agency_Name">
                                <?php $__errorArgs = ['Agency_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            </div>
                        </div>
                    
                </div> 
            
                <hr>
                
                <h3>Booking Department</h3> 
                <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group col-sm-auto">
                                <label for="exampleFormControlInput">First Name</label>
                                <input type="text" class="form-control" id="exampleFormControlInput" placeholder="First Name" value="<?php echo e($First_Name); ?>" name="First_Name">
                                <?php $__errorArgs = ['First_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    
                            <div class="form-group col-sm-auto">
                                <label for="exampleFormControlInput">Last Name</label>
                                <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Last Name" value="<?php echo e($Last_Name); ?>" name="Last_Name">
                                <?php $__errorArgs = ['Last_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group col-sm-auto">
                                <label for="exampleFormControlInput">Email</label>
                                <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Email" value="<?php echo e($Email); ?>" name="Email">
                                <?php $__errorArgs = ['Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        
                            <div class="form-group col-sm-auto">
                                <label for="exampleFormControlInput">Email2</label>
                                <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Email2" value="<?php echo e($Email2); ?>" name="Email2">
                                <?php $__errorArgs = ['Email2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group col-sm-auto">
                                <label for="exampleFormControlInput">Phone</label>
                                <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Phone" value="<?php echo e($Phone); ?>" name="Phone">
                                <?php $__errorArgs = ['Phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        
                            <div class="form-group col-sm-auto">
                                <label for="exampleFormControlInput">Mobile</label>
                                <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Mobile" value="<?php echo e($Mobile); ?>" name="Mobile">
                                <?php $__errorArgs = ['Mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group col-sm-auto">
                                <label for="exampleFormControlInput">Emergency Phone</label>
                                <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Emergency Phone" value="<?php echo e($Emergency_Phone); ?>" name="Emergency_Phone">
                                <?php $__errorArgs = ['Emergency_Phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
                        
                <div id="notif"></div>
            </div>
            <hr>
            <h3>Escalation</h3> 
            
            <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group col-sm-auto">
                            <label for="exampleFormControlInput">First Name</label>
                            <input type="text" class="form-control" id="exampleFormControlInput" placeholder="First Name" value="<?php echo e($First_Name_1); ?>" name="First_Name_1">
                            <?php $__errorArgs = ['First_Name_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    
                        <div class="form-group col-sm-auto">
                            <label for="exampleFormControlInput">Last Name</label>
                            <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Last Name" value="<?php echo e($Last_Name_1); ?>" name="Last_Name_1">
                            <?php $__errorArgs = ['Last_Name_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group col-sm-auto">
                            <label for="exampleFormControlInput">Email</label>
                            <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Email" value="<?php echo e($Email_1); ?>" name="Email_1">
                            <?php $__errorArgs = ['Email_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    
                        <div class="form-group col-sm-auto">
                            <label for="exampleFormControlInput">Email2</label>
                            <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Email2" value="<?php echo e($Email2_1); ?>" name="Email2_1">
                            <?php $__errorArgs = ['Email2_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group col-sm-auto">
                            <label for="exampleFormControlInput">Phone</label>
                            <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Phone" value="<?php echo e($Phone_1); ?>" name="Phone_1">
                            <?php $__errorArgs = ['Phone_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    
                        <div class="form-group col-sm-auto">
                            <label for="exampleFormControlInput">Mobile</label>
                            <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Mobile" value="<?php echo e($Mobile_1); ?>" name="Mobile_1">
                            <?php $__errorArgs = ['Mobile_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group col-sm-auto">
                            <label for="exampleFormControlInput">Emergency Phone</label>
                            <input type="text" class="form-control" id="exampleFormControlInput" placeholder="Emergency Phone" value="<?php echo e($Emergency_Phone); ?>" name="Emergency_Phone">
                            <?php $__errorArgs = ['Emergency_Phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    
                       
                    </div>
            </div>
            <hr> 
            <div class="row"> 
                   
                    <div class="col-sm-6">
                        <div class="form-group col-sm-auto">
                            <label>Contact Type</label>
                            <select class="form-control" id="Contact_Type" value="Contact_Type " name="Contact_Type">
                            <option  value="">Select Type</option>
                            <option <?php if($Contact_Type=='SELLER'): ?> selected <?php endif; ?> value="SELLER">Seller</option>
                            <option <?php if($Contact_Type=='BUYER'): ?> selected <?php endif; ?>  value="BUYER">Buyer</option>
                            <option <?php if($Contact_Type=='HSS'): ?> selected <?php endif; ?>  value="HSS">HSS</option>
                            </select>
                            <?php $__errorArgs = ['Contact_Type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-sm-auto">
                            <label for="exampleFormControlInput">Code country</label>
                            <input type="text" class="form-control" id="exampleFormControlInput" placeholder="ZIP code" value="<?php echo e($ZIP_code); ?>" name="ZIP_code">
                            <?php $__errorArgs = ['ZIP_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group col-sm-auto">
                            <label for="exampleFormControlInput">Billing Country</label>
                        
                            <input class="form-control" name="Billing_Country" type="text" list="select-contry" placeholder="Select Country" value="<?php echo e($Billing_Country); ?>" >
                            <datalist id="select-contry">
                            
                                <option value="">Select Country</option>
                                
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country->nom_en_gb); ?>"><?php echo e($country->nom_en_gb); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </datalist>  
                            <?php $__errorArgs = ['Billing_Country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     
                    </div>
            
        
            </div>

            <hr>
        
            
                


            
            
                <div class="modal-footer">

                    <button type="button" class="btn btn-danger" data-dismiss="modal">Fermer</button>
                    <button type="submit" class="btn btn-success" id="copy">Enregistre</button>

                </div>
                
            </div>
      </form>
    </div>
</div>
</div>
 
<?php /**PATH /home2/bedscect/crm.bedsconnect.com/resources/views/admin/agencys/pop_up/pop_up_edit_agency.blade.php ENDPATH**/ ?>