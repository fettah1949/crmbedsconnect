<?php
    $category_name = 'contact';
    $page_name = 'agencys';
    $has_scrollspy = 0;
    $scrollspy_offset = '';
?>

 
<?php $__env->startSection('content'); ?>

<br>
<hr>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left text-center">
                <h2 class="text-primary">Agency List</h2>
            </div>
            <hr>
            <div class="pull-right">
                <a class="btn btn-outline-primary btn-rounded mb-2" href="<?php echo e(route('agencylist.create')); ?>"> New Agency</a>
            </div>
            <br>
        </div>
    </div>

<div class="table-responsive">
    <table class="table table-bordered table-striped mb-4" id="hotels-table">
        
        <thead>
            <tr>
                <th>.</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Country</th>
                <th>Type</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $agencys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>-</td>
                <td><?php echo e($value->Agency_Name); ?></td>
                <td><?php echo e($value->Email); ?></td>
                <td><?php echo e($value->Phone); ?></td>
                <td><?php echo e($value->Billing_Country); ?></td>
                <td><?php echo e($value->Contact_Type); ?></td>
    
                <td>
                    <a class="btn btn-outline-primary mb-2" href="<?php echo e(route('agencylist.edit',$value["id"])); ?>">
                        <svg xmlns='http://www.w3.org/2000/svg' width='30' height='30' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-edit-2 p-1 br-6 mb-1'>
                            <path d='M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z'></path></svg>
                    </a> 
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
    </tbody>
</table>
</div>

      
<?php $__env->stopSection(); ?>

  

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bdseconnect\resources\views/admin/agencys/index.blade.php ENDPATH**/ ?>