

<?php $__env->startSection('content'); ?>
<div class="layout-px-spacing">
                
    <div class="row layout-top-spacing" id="cancel-row">
    
        <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
            
        </div>

    </div>

</div>



<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\www\resources\views/reservation_detail.blade.php ENDPATH**/ ?>