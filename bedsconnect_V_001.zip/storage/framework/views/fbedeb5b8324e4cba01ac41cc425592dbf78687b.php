
<?php
use App\Models\Agencycontact;
use App\Models\Hotellist;

$sellers = Agencycontact::where('Contact_Type','SELLER')->get();
$buyers = Agencycontact::where('Contact_Type','BUYER')->get();



   $hotels = Hotellist::all();
?>
                            <div class="panel-body"     display:inline-block >
                               
                                   <form   action="<?php echo e(route('reservation.create')); ?>" method="PUT">
                                       <?php echo csrf_field(); ?>
                                     <div class="row">
                                          <div class="form-group" >
                                         <label  for="start_date" class="control-label col-sm-auto" >Start Date: </label>
                                           <div class="col-sm-auto" >
                                               <input type="date" class="form-control" id="start_date" name="start_date" />
                                               <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                           </div>
                                             </div>
                                             <div class="form-group">
                                               <label for="end_date" class="control-label col-sm-auto">End Date: </label>
                                                 <div class="col-sm-auto">
                                                   <input type="date" class="form-control" id="end_date" name="end_date"  />
                                                   <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                               </div>
                                             </div>
                                             
                                             <div class="form-group">
                                               <label for="date_type" class="control-label col-sm-auto">Date Type: </label>
                                                 <div class="col-sm-auto">
                                                   <select class="form-control" id="date_type" name="date_type"  >
                                                     <option value="">Select Type</option>
                                                     <option value="bookingDate">Booking Date</option>
                                                     <option value="checkinDate">Checkin Date</option>
                                                     <option value="checkoutDate">Checkout Date</option>
                                                     <option value="lastActionDate">LastAction Date</option>
                                                   </select>                                            
                                                   <?php $__errorArgs = ['date_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                               </div>
                                             </div>
                        
                                             <div class="form-group">
                                               <label for="status" class="control-label col-sm-auto">Status: </label>
                                               <div class="col-sm-auto">
                                                 <select class="form-control" id="status" name="status"  >
                                                    <option value="">Select Status</option>
                                                    <option value="CN">Cancelled</option>
                                                   <option value="OK">Confirmed</option>
                                                   <option value="KUN">Unknown Status</option>
                                                   <option value="CN-FEE">Cancelled Whith Fee</option>
                                                   <option value="CN-NRF">Cancelled Non Refundable</option>
                                                   <option value="NO-SHOW">No-Show</option>
                                                 </select>
                                                 <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                               </div>
                                             </div>
                                           </div>
                        
                                   <div class="row">
                                       <div class="form-group">
                                         <label for="service_category" class="control-label col-sm-auto">Hotel: </label>
                                           <div class="col-sm-auto">
                                               <select class="form-control" id="hotel" name="hotel"  >
                                                     <option value="">Select Hotel</option>
                                                      <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                          <option value="<?php echo e($hotel->Hotel_Code); ?>"><?php echo e($hotel->Hotel_Name); ?></option>
                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                             <?php $__errorArgs = ['hotel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                                         </div>
                                       </div>
                        
                                       
                                       <div class="form-group">
                                         <label for="agency" class="control-label col-sm-auto">Buyer: </label>
                                           <div class="col-sm-auto">
                                            <select class="form-control" id="agency" name="agency"   >
                                              <option value="">Select Buyer</option>
                                               <?php $__currentLoopData = $buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <option value="<?php echo e($buyer->Agency_ID); ?>"><?php echo e($buyer->Agency_Name); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </select>
                                             <?php $__errorArgs = ['agency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                                         </div>
                                       </div>
                        
                                       <div class="form-group">
                                         <label for="provider" class="control-label col-sm-auto">Seller: </label>
                                           <div class="col-sm-auto">
                                            <select class="form-control" id="provider" name="provider" >
                                              <option value="">Select Seller</option>
                                               <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <option value="<?php echo e($seller->Agency_Name); ?>"><?php echo e($seller->Agency_Name); ?></option>
                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         </select>
                                             <?php $__errorArgs = ['provider'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-danger"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                                         </div>
                                       </div>
                                       
                                       
                                                    
                                        <div class="form-group col-sm-auto">
                                          <label>Payment Status</label>
                                          <select class="form-control" name="Payment_Status" id="Payment_Status">
                                              <option value="">Select Status</option>
                                              <option value="Payed">Payed</option>
                                              <option value="Not-Payed">Not-Payed</option>
                                            </select>
                                          <?php $__errorArgs = ['Payment_Status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                      </div>

                                   
                                     </div>
                               
                                     <button type="submit" class="btn btn-outline-success mb-2">Apply</button>
                                     <button type="reset" class="btn btn-outline-secondary mb-2">Clear</button>
                                   </form>
                                   <br>
                                   <?php if(Session::has('message')): ?>
                                   <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                               <?php endif; ?>
                            </div>
                        
                        <?php /**PATH C:\xampp\htdocs\www\resources\views/reservation/tab-filter.blade.php ENDPATH**/ ?>