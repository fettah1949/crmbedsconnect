<?php
use App\Models\Hotellist;
$hotels = Hotellist::all();


use App\Models\Room;
$rooms = Room::all();


    $category_name = 'production';
    $page_name = 'hotel_room_list';
    $has_scrollspy = 0;
    $scrollspy_offset = '';

    if( isset( $hotel ) ) {
       $HotelName = $hotel->Hotel_Name;
       $HotelCode = $hotel->Hotel_Code;
       $ht='1';
        }else {
        $HotelName = "";
        $HotelCode = "";
        $ht='2';

    }
?>

  
<?php $__env->startSection('content'); ?>
<br>

<?php if( $ht === '1'): ?>
<nav class="breadcrumb-two" aria-label="breadcrumb">
    <ol style="background: none" class="breadcrumb">
        <li class="breadcrumb-item active"><a href="<?php echo e(route('hotelrooms.index')); ?>">All Rooms List</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">Add New Room To</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('hotellist.show',$HotelCode)); ?>"><?php echo e($HotelName); ?> : <?php echo e($HotelCode); ?></a></li>
    </ol>
</nav>
<?php endif; ?>

<?php if( $ht === '2'): ?>
<nav class="breadcrumb-two" aria-label="breadcrumb">
    <ol style="background: none" class="breadcrumb">
        <li class="breadcrumb-item active"><a href="<?php echo e(route('hotelrooms.index')); ?>">Rooms List</a></li>
        <li class="breadcrumb-item" aria-current="page"><a href="javascript:void(0);">Add New Room</a></li>
    </ol>
</nav>

<?php endif; ?>

 
<hr>
   
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
   
<form action="<?php echo e(route('hotelrooms.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
  

    
    <?php if( $ht === '1'): ?>

    <div class="row">
                        
        <div class="form-group col-sm-auto">
            <label for="Room_Id">Room Id</label>
            <input class="form-control" type="text" list="select-room-id" id="Room_Id" name="Room_Id" placeholder="Select Room Id" onkeyup='setRoomName();'>
            <datalist  id="select-room-id">
            <option value="">Select Room ID</option>
             <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <input type=hidden  id="<?php echo e($room->Room_Id); ?>" value="<?php echo e($room->Room_Name); ?>" />
                 <option value="<?php echo e($room->Room_Id); ?>"><?php echo e($room->Room_Id); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </datalist>
            <?php $__errorArgs = ['Room_Id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
                    
        <div class="form-group col-sm-auto">
            <label for="Room_Name">Room Name</label>
            <input class="form-control" type="text" list="select-room" id="Room_Name" name="Room_Name" placeholder="Select Room Name" onkeyup='setRoomId();'>
            <datalist  id="select-room">
            <option value="">Select Room Name</option>
             <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <input type=hidden  id="<?php echo e($room->Room_Name); ?>" value="<?php echo e($room->Room_Id); ?>" />
                 <option value="<?php echo e($room->Room_Name); ?>"><?php echo e($room->Room_Name); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </datalist>
            <?php $__errorArgs = ['Room_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
            
            <div class="form-group col-sm-auto">
                <input class="form-control" type="hidden" name="Hotel_Name" value="<?php echo e($HotelName); ?>">
            </div>
       
            
            <div class="form-group col-sm-auto">
                <input class="form-control" type="hidden"  name="Hotel_Code" value="<?php echo e($HotelCode); ?>">
            </div>
       
    </div>
    
    <hr>

    <?php endif; ?>

    <?php if( $ht === '2'): ?>

    
        <div class="row">
                        
            <div class="form-group col-sm-auto">
                <label for="Room_Id">Room Id</label>
                <input class="form-control" type="text" list="select-room-id" id="Room_Id" name="Room_Id" placeholder="Select Room Id" onkeyup='setRoomName();'>
                <datalist  id="select-room-id">
                <option value="">Select Room ID</option>
                 <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <input type=hidden  id="<?php echo e($room->Room_Id); ?>" value="<?php echo e($room->Room_Name); ?>" />
                     <option value="<?php echo e($room->Room_Id); ?>"><?php echo e($room->Room_Id); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </datalist>
                <?php $__errorArgs = ['Room_Id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
                        
            <div class="form-group col-sm-auto">
                <label for="Room_Name">Room Name</label>
                <input class="form-control" type="text" list="select-room" id="Room_Name" name="Room_Name" placeholder="Select Room Name" onkeyup='setRoomId();'>
                <datalist  id="select-room">
                <option value="">Select Room Name</option>
                 <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <input type=hidden  id="<?php echo e($room->Room_Name); ?>" value="<?php echo e($room->Room_Id); ?>" />
                     <option value="<?php echo e($room->Room_Name); ?>"><?php echo e($room->Room_Name); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </datalist>
                <?php $__errorArgs = ['Room_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
                
                <div class="form-group col-sm-auto">
                    <label for="Hotel_Name">Hotel Name</label>
                    <input class="form-control" type="text" list="select-hotel" id="Hotel_Name" name="Hotel_Name" placeholder="Select Hotel" onkeyup='setHotelCode();'>
                    <datalist  id="select-hotel">
                    <option value="">Select Hotel</option>
                     <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <input type=hidden  id="<?php echo e($hotel->Hotel_Name); ?>" value="<?php echo e($hotel->Hotel_Code); ?>" />
                         <option value="<?php echo e($hotel->Hotel_Name); ?>"><?php echo e($hotel->Hotel_Name); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist>
                    <?php $__errorArgs = ['Hotel_Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
           
                
                <div class="form-group col-sm-auto">
                    <label for="Hotel_Code">Hotel Code</label>
                    <input class="form-control" type="text" list="select-hotel-code" id="Hotel_Code" name="Hotel_Code" placeholder="Select Hotel Code" onkeyup='setHotelName();'>
                    <datalist  id="select-hotel-code">
                    <option value="">Select Hotel</option>
                     <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <input type=hidden  id="<?php echo e($hotel->Hotel_Code); ?>" value="<?php echo e($hotel->Hotel_Name); ?>" />
                         <option value="<?php echo e($hotel->Hotel_Code); ?>"><?php echo e($hotel->Hotel_Code); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist>
                    <?php $__errorArgs = ['Hotel_Code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
           
        </div>
        
        <hr>
    <?php endif; ?>



                <div class="col-xs-12 col-sm-12 col-md-12 text-center">

                    <button type="submit" class="btn btn-outline-success mb-2">Save</button>
                    <button style="margin-left: 20px" type="reset" class="btn btn-outline-danger mb-2">Clear</button>
                
                </div>
</form>
<script>
    function setHotelCode(){
          var h_code = document.getElementById("Hotel_Name").value;
      document.getElementById("Hotel_Code").value = document.getElementById(h_code).value ;      
      }
      
      
      function setHotelName(){
            var h_name = document.getElementById("Hotel_Code").value;
        document.getElementById("Hotel_Name").value = document.getElementById(h_name).value ;      
        }
        
    function setRoomName(){
          var r_code = document.getElementById("Room_Id").value;
      document.getElementById("Room_Name").value = document.getElementById(r_code).value ;      
      }
      
      
      function setRoomId(){
            var r_name = document.getElementById("Room_Name").value;
        document.getElementById("Room_Id").value = document.getElementById(r_name).value ;      
        }
        
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/bedscect/ops.bedsconnect.com/resources/views/admin/hotels/hotelrooms/create.blade.php ENDPATH**/ ?>