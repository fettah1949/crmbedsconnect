<?php

namespace App\Http\Controllers;

use App\Http\Middleware\Client_Seller;
use App\Models\Client_seller as ModelsClient_seller;
use App\Models\Reservation;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Auth\SessionGuard;
class ClientController extends Controller
{

    
    public function __construct()
    {
        // $this->middleware('guest')->except('logout');
        //  $this->middleware('guest:client_seller');
        //    $this->middleware('guest')->except('logout');
            // $this->middleware('guest:admin')->except('logout');
            // $this->middleware('guest:client_seller')->except('logout');
    }
    public function index()
    {
        return view('client.liste_reservation_seller');  
    }
    public function login_seller()
    {
        if(Auth::guard('Client_seller')->id()!=null)
        {
            $dt =  Carbon::now();
        $dt= $dt->format('Y-m-d');
        $date1= $dt;
            $id= Auth::guard('Client_seller')->id() ;
            // return $id;
            $seller = ModelsClient_seller::where('id',$id)->first();
            // return $seller->seller;
            $reservations = Reservation::
                // whereDate('bookingDate','>=', $date2)
                // join('hotellists', 'reservations.hotelCode', '=', 'hotellists.Hotel_Code')
                where('status','=','OK')
                // ->whereNull('HCN_AC')
                 ->orderBy('checkinDate','DESC')
                 ->whereDate('checkinDate','>=', $date1)
                 ->select('*','reservations.providerName  as providerName','reservations.provider  as provider',
                 'reservations.HotelName as Hotel_Name')     
                 ->where('reservations.providerName',$seller->seller)
                 ->get();
          //   return $reservations;
                return view('client.liste_reservation_seller',array('Reservations'=>$reservations));  
        }else{
            return view('client.login_seller');  
        }
       
    }
    public function add_Note(Request $request)
    {
        //  return $request;
        $dt =  Carbon::now();
        $dt= $dt->format('Y-m-d');
        $date1= $dt;
        // return $date1;
        $resa =  Reservation::find($request['tgx']);
             
         $resa ->Note = $request['note'];  
      
        $resa -> save(); 
        $id= Auth::guard('Client_seller')->id() ;
        // return $id;
        $seller = ModelsClient_seller::where('id',$id)->first();
        // return $seller->seller;
        $reservations = Reservation::
            // whereDate('bookingDate','>=', $date2)
            // join('hotellists', 'reservations.hotelCode', '=', 'hotellists.Hotel_Code')
            where('status','=','OK')
            // ->whereNull('HCN_AC')
             ->orderBy('checkinDate','DESC')
             ->whereDate('checkinDate','>=', $date1)
             ->select('*','reservations.providerName  as providerName','reservations.provider  as provider',
             'reservations.HotelName as Hotel_Name')     
             ->where('reservations.providerName',$seller->seller)
             ->get();
     //   return $reservations;
            return view('client.liste_reservation_seller',array('Reservations'=>$reservations));  
    }
    public function update_seller(Request $request)
    {
        // return $request;
        $dt =  Carbon::now();
        $dt= $dt->format('Y-m-d');
        $date1= $dt;
        // return $date1;
        $resa =  Reservation::find($request['tgx']);
             
         $resa ->HCN_AC = $request['HCN'];  
         $resa ->Agent_name = $request['Agent_Name'];
                    
        $resa -> save(); 
        $id= Auth::guard('Client_seller')->id() ;
        // return $id;
        $seller = ModelsClient_seller::where('id',$id)->first();
        // return $seller->seller;
        $reservations = Reservation::
            // whereDate('bookingDate','>=', $date2)
            // join('hotellists', 'reservations.hotelCode', '=', 'hotellists.Hotel_Code')
            where('status','=','OK')
            // ->whereNull('HCN_AC')
             ->orderBy('checkinDate','DESC')
             ->whereDate('checkinDate','>=', $date1)
             ->select('*','reservations.providerName  as providerName','reservations.provider  as provider',
             'reservations.HotelName as Hotel_Name')     
             ->where('reservations.providerName',$seller->seller)
             ->get();
      //   return $reservations;
            return view('client.liste_reservation_seller',array('Reservations'=>$reservations));  
    }

    public function login_auth_seller(Request $request)
    {
        //  dd(Auth::check())   ;
        //  return $request;
        $dt =  Carbon::now();
        $dt= $dt->format('Y-m-d');
        $date1= $dt;
        $attempt = Auth::guard('Client_seller')
        ->attempt(['email' => $request->email,
         'password' => $request->password]);
        // return Auth::guard('Client_seller')->id();
        if(Auth::guard('Client_seller')->id()!=null)
        {
              
        //   return Auth::getDefaultDriver();
          
                //   return $seller->seller;
        if($attempt)
        {  
            $id= Auth::guard('Client_seller')->id() ;
            $seller = ModelsClient_seller::where('email',$request['email'])

              ->first();
            // return  $id = Auth::id();
            // return $request;
            
            $reservations = Reservation::
            // whereDate('bookingDate','>=', $date2)
            // join('hotellists', 'reservations.hotelCode', '=', 'hotellists.Hotel_Code')
            where('status','=','OK')
            // ->whereNull('HCN_AC')
            //  ->orderBy('checkinDate','ASC')
             ->whereDate('checkinDate','>=', $date1)
              ->select('*','reservations.providerName  as providerName','reservations.provider  as provider',
              'reservations.HotelName as Hotel_Name')
             ->where('reservations.providerName',$seller->seller)
             ->get();
                 //   return $reservations;
            return view('client.liste_reservation_seller',array('Reservations'=>$reservations));  
        }else
        {
            return view('client.login_seller'); 
        }
        }
        else
        {
            return view('client.login_seller'); 
        }
        
    }
    public function logout_seller(Request $request)
    {
        Auth::guard('Client_seller')->logout();
        return view('client.login_seller');  
    }
}
