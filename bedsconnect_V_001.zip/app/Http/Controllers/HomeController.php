<?php

namespace App\Http\Controllers;

use App\Models\Agencycontact;
use App\Models\Client_seller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
          $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('dashboard2');
    }
    public function seller_setup()
    {
        // $sellers = Agencycontact::where('Contact_Type','SELLER')->get();
        $sellers = Agencycontact::where('Contact_Type','SELLER')->get();
        $Client_seller = Client_seller::All();

        // return $sellers;
        return view('admin.seller.add_seller',array('Client_seller'=>$Client_seller,'sellers'=>$sellers));  
    }
    public function add_register(Request $request)
    {
        $data = $request->all();
        // return $data ;
        // $this->validate($request,[
        //     'email' => 'required|email|max:255',
        //     'password' => 'required|min:6|max:30|confirmed',

        // ]);

        $cl = Client_seller::create([
            'email'=>$data['Email_seller'],
            'name'=>$data['nom'],
            'seller'=>$data['provider'],
            'password' => Hash::make($data['password_seller']),
            'verification_code'=> sha1(time())

        ]);
        // return $cl;
        $sellers = Agencycontact::where('Contact_Type','SELLER')->get();
        $Client_seller = Client_seller::All();
        
        return view('admin.seller.add_seller',array('Client_seller'=>$Client_seller,'sellers'=>$sellers))
        ->with('status', "Le Seller est crée avec success  " );  
    }
    public function edit_register(Request $request)
    {
        $data = $request->all();
        // return $data ;
        // $this->validate($request,[
        //     'email' => 'required|email|max:255',
        //     'password' => 'required|min:6|max:30|confirmed',

        // ]);
        $Client =  Client_seller::find($data['id']);
             
        $Client ->email = $data['email'];  
        $Client ->name = $data['username'];
        $Client ->seller = $data['provider'];
        if(isset($data['passwords']))
        {
          $Client ->password = Hash::make($data['passwords']);  
        }
        
       $Client -> save(); 
     
        // return $cl;
        $sellers = Agencycontact::where('Contact_Type','SELLER')->get();
        $Client_seller = Client_seller::All();
        
        return view('admin.seller.add_seller',array('Client_seller'=>$Client_seller,'sellers'=>$sellers))
        ->with('status', "Le Seller est crée avec success  " );  
    }
    public function indexuser()
    {
        $user = User::all();
        $data = [
            'category_name' => 'admin',
            'page_name' => 'user_setup',
            'has_scrollspy' => 0,
            'scrollspy_offset' => '',
           

        ];


        // return $user; 
        // $pageName = 'user_setup';
        return view('user',array( 'user'=> $user))->with($data);
    }
    public function add_user(Request $request)
    {
        // return $request;
        $data = $request->all();
        //  return $data ;
        // $this->validate($request,[
        //     'email' => 'required|email|max:255',
        //     'password' => 'required|min:6|max:30|confirmed',

        // ]);

        $cl = User::create([
            'name'=>$data['nom'],
            'email'=>$data['Email_user'],
            'password' => Hash::make($data['password_user']),
            'role'=>$data['role'],
            
         

        ]);

        return redirect()->back()->with('status','User est ajouter avec success ');
    }
    public function edit_user(Request $request)
    {
        // return $request;
        $data = $request->all();
        $User =  User::find($data['id']);
             
        $User ->email = $data['email'];  
        $User ->name = $data['username'];
        $User ->role = $data['role'];
        if(isset($data['passwords']))
        {
          $User ->password = Hash::make($data['passwords']);  
        }
        
       $User -> save(); 

        return redirect()->back()->with('status','User est Modifier avec success ');
    }
    public function logout_user(Request $request)
    {
        // Auth::guard('Client_seller')->logout();
        Auth::logout();
        return redirect('/login');
    }
    public function delete_seller(Request $request)
    {
        $data = $request->all();
        // return $data;
        $res=Client_seller::where('id',$data['id'])->delete();
       
 
         return redirect()->back()->with('status','User est supprimé avec success ');
 
     }
     public function delete_user(Request $request)
     {
         $data = $request->all();
         // return $data;
         $res=User::where('id',$data['id'])->delete();
        
  
          return redirect()->back()->with('status','User est supprimé avec success ');
  
      }
    // public function conxnew(Request $request)
    // {

    //     return  $request;
    //     // if(Auth::guard('client')->attempt(['email'=>$request->email,'password'=>$request->password,'is_verified'=>1],$request->remember))
    //     // {
            
    //     // }

    // }
}
