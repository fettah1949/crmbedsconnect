<?php
function getBadge($var){
    switch($var){
        case "CN":
            return "badge-danger";
        case "OK":
            return "badge-success";
        case "CK":
            return "badge-secondary";
        case "KUN":
            return "badge-secondary";
        case "CN-FEE":
            return "badge-info";
        case "CN-NRF":
            return "badge-primary";
        case "NO-SHOW":
            return "badge-dark";

        // invoice status badge

        case "Invoiced":
            return "badge-success";
        case "Refund":
            return "badge-danger";
        case "Due":
            return "badge-secondary";
            

        // Payment status badge

        case "Payed":
            return "badge-success";
        case "Not-Payed":
            return "badge-danger";



    }
}

            $category_name = 'production';
            $page_name = 'reservation_seller';
            $has_scrollspy = 0;
            $scrollspy_offset = '';

?>
    <!-- BEGIN PAGE LEVEL STYLES -->
    <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/datatables.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('plugins/table/datatable/dt-global_style.css')}}">
    <link rel="icon" type="image/x-icon" href="{{asset('assets/img/favicon.ico')}}"/>
    <link href="{{asset('assets/css/loader.css')}}" rel="stylesheet" type="text/css" />
    <script src="{{asset('assets/js/loader.js')}}"></script>
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
    <link href="{{asset('bootstrap/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('assets/css/plugins.css')}}" rel="stylesheet" type="text/css" />
    <!-- END GLOBAL MANDATORY STYLES -->
    

@extends('layouts.app')
@section('content')
 <!--  BEGIN NAVBAR  -->
 {{-- <div class="header-container fixed-top"> --}}
    {{-- <header class="header navbar navbar-expand-sm">

        <ul class="navbar-item theme-brand flex-row  text-center">
            <li class="nav-item theme-logo">
                <a>
                    <img src="{{asset('storage/img/90x90.jpg')}}" class="navbar-logo" alt="logo">
                </a>
            </li>
            <li class="nav-item theme-text">
                <a  class=""> {{ Auth::guard('Client_seller')->user()->name }} </a>
            </li>
             
                
            

     
        </ul>

   


    </header> --}}
{{-- </div> --}}
<!--  BEGIN NAVBAR  -->
<div class="header-container fixed-top">
    <header class="header navbar navbar-expand-sm">

        <ul class="navbar-item theme-brand flex-row  text-center">
            <li class="nav-item theme-logo">
                <a >
                    <img src="{{asset('storage/img/90x90.jpg')}}" class="navbar-logo" alt="logo">
                </a>
            </li>
            <li class="nav-item theme-text">
                <a class="nav-link"> {{ Auth::guard('Client_seller')->user()->name }} </a>
            </li>
        </ul>



        <ul class="navbar-item flex-row ml-md-auto">
            @if ($category_name != 'starter_kits')
   

        
            @endif
            
            <li class="nav-item dropdown user-profile-dropdown">
                <a style="color: red" href="javascript:void(0);" class="nav-link dropdown-toggle user" id="userProfileDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                    <img src="{{asset('storage/img/90x90.jpg')}}" alt="avatar">  Sign Out
                </a>
                <div class="dropdown-menu position-absolute" aria-labelledby="userProfileDropdown">
                    <div class="">
                        
                  
                        <div class="dropdown-item">
                            <a href="{{ route('logout_seller') }}" 
                        ><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-log-out"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg> Sign Out</a>
                        </div>
                        
                    </div>
                </div>
            </li>

        </ul> 
    </header>
</div>
<!--  END NAVBAR  -->




<br>
    <div style="margin-left: -218px !important;" class="main-container widget-content widget-content-area br-6" id="container">

            

        

       
                
                
                            {{-- <table id="zero-config" class="table" style="width:100%">
                                <thead>
                                    <tr>
                                        <th class="text-center " >Status</th>
                                        
                                            <th>File number</th>
                                            <th>Hotel</th> 
                                            <th>Agent Name</th>
                                            
                                            <th>HCN</th>
                                        
                                            <th class="mt ">Booking_Date</th>
                                            <th>Check_In_Date</th>
                                            <th>Check_Out_Date</th>
                                             
                                    </tr>
                                </thead>
                                <tbody >
                            
                        
                                    @foreach($Reservations as $row)
                                    <tr class='res_tab' >
                                        <td class='text-center'><span class='shadow-none badge   '>

                                            {{ $row["status"] }}
                                            @if($row["status"]=='CN')
                                            <div class="t-dot bg-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>
                                            @elseif($row["status"]=='OK')
                                            <div class="t-dot bg-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>
                                            @elseif($row["status"]=='CK')
                                            <div class="t-dot bg-secondary" data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>
                                            @elseif($row["status"]=='KUN')
                                            <div class="t-dot bg-secondary" data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>
                                            @elseif($row["status"]=='NO-SHOW')
                                            <div class="t-dot " data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>

                                            @endif


                                        
                                        </span></td>
                                        <td class='provider' reservation-provider = '{{ $row["provider_h"] }}'>{{ $row["provider_h"] }}</td>
                                        <td class='hotelCode' reservation-hotelCode = '{{ $row["Hotel_Name"] }}'>{{ $row["Hotel_Name"] }}</td>
                                        <td class='client' reservation-client = '{{ $row["client"] }}'></td>
                                        <td class='providerName' style="display:none" reservation-providerName = '{{$row["providerName"]}}'>{{ $row["providerName"] }}</td>
                                        <td class='mainGuestName'  style="display:none" reservation-mainGuestName = '{{$row["mainGuestName"]}}'>{{ $row["mainGuestName"] }}</td>
                                        <td >{{ $row["HCN_AC"] }}</td>
                                        @php
                                        $bookingDate = explode(" ", $row["bookingDate"]);
                                        $checkinDate = explode(" ", $row["checkinDate"]);
                                        $checkoutDate = explode(" ", $row["checkoutDate"]);
                            
                                        @endphp
                                        <td class='bookingDate' reservation-bookingDate = '{{date('d-m-Y', strtotime($bookingDate[0]))}}'> {{date('d-m-Y', strtotime($bookingDate[0]))}} {{date('H:s', strtotime($bookingDate[1]))}}</td>
                                        
                                        <td class='checkinDate' reservation-checkinDate = '{{$row["checkinDate"]}}'>{{date('d-m-Y', strtotime($checkinDate[0]))}}</td>
                                        
                                        <td class='checkoutDate' reservation-checkoutDate = '{{$row["checkoutDate"]}}'>{{date('d-m-Y', strtotime($checkoutDate[0]))}}</td>
                                        
                                       
                                        
                                        
                                          
                                    </tr>
                        
                                    @endforeach 
                                </tbody>
                            </table> --}}


                            <table id="default-ordering" class="table" style="width:100%">
                                <thead>
                                    <tr>
                                          <th class="text-center" >Status</th>
                                        
                                            <th>File number</th>
                                            <th>Hotel</th> 
                                            <th>Hotel Reservation Agent</th>
                                            
                                            <th>HCN</th>
                                        
                                            <th class="">Booking Date</th>
                                            <th>Check_In Date</th>
                                            <th>Check_Out Date</th>
                                            <th></th>
                                             
                                    </tr>
                                </thead>
                                <tbody >
                              
                        
                             {{-- {{'ffff'. $Reservations[0]->provider_h  }} --}}
                                    @foreach($Reservations as $row)
                                    {{-- {{ $row }} --}}
                                    <tr class='' >
                                        {{-- <td class='checkbox-column'  ></td>               {{ getBadge($row["status"]) }}              --}}
                                        <td class='text-center'><span class='shadow-none badge   '>

                                            {{ $row["status"] }}
                                            @if($row["status"]=='CN')
                                            <div class="t-dot bg-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>
                                            @elseif($row["status"]=='OK')
                                            <div class="t-dot bg-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>
                                            @elseif($row["status"]=='CK')
                                            <div class="t-dot bg-secondary" data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>
                                            @elseif($row["status"]=='KUN')
                                            <div class="t-dot bg-secondary" data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>
                                            @elseif($row["status"]=='NO-SHOW')
                                            <div class="t-dot " data-toggle="tooltip" data-placement="top" title="" data-original-title="High"></div>

                                            @endif


                                        
                                        </span></td>
                                        <td class='provider' reservation-provider = '{{ $row["provider"] }}'>{{ $row["provider"] }}</td>
                                        <td class='hotelCode' reservation-hotelCode = '{{ $row["Hotel_Name"] }}'>{{ $row["Hotel_Name"] }}</td>
                                        <td class='Agent_name' reservation-client = '{{ $row["Agent_name"] }}'>{{$row["Agent_name"]}}</td>
                                        <td >{{ $row["HCN_AC"] }}</td>
                                        @php
                                        $bookingDate = explode(" ", $row["bookingDate"]);
                                        $checkinDate = explode(" ", $row["checkinDate"]);
                                        $checkoutDate = explode(" ", $row["checkoutDate"]);
                               
                                        @endphp
                                        <td class='bookingDate' reservation-bookingDate = '{{date('Y-m-d', strtotime($bookingDate[0]))}}'> {{date('d-m-Y', strtotime($bookingDate[0]))}} {{date('H:s', strtotime($bookingDate[1]))}}</td>
                                        
                                        <td class='checkinDate' reservation-checkinDate = '{{$row["checkinDate"]}}'>{{$row["checkinDate"]}}</td>
                                        
                                        <td class='checkoutDate' reservation-checkoutDate = '{{$row["checkoutDate"]}}'>{{date('Y-m-d', strtotime($checkoutDate[0]))}}</td>
                                        
                                        <td>
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-success btn-sm">Confirm</button>
                                                <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuReference3">
                                                    <a class="dropdown-item" data-toggle="modal" data-target="#edit_reservation-{{$row["tgx"]}}" target="_blank">
                                                        Edit
                                                        <svg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='feather feather-edit-2 p-1 br-6 mb-1'>
                                                        <path d='M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z'></path></svg></a>
                                                    
                                                      
                                                    <div class="dropdown-divider"></div>
                                                    <a class="dropdown-item"  data-toggle="modal" data-target="#Note_reservation-{{$row["tgx"]}}" target="_blank">
                                                        Note
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#1b55e2 " stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file-plus"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="18" x2="12" y2="12"></line><line x1="9" y1="15" x2="15" y2="15"></line></svg>

                                                    </a>
                                                  
                                              
                                                </div>
                                            </div>

                                        </td>
                                 
                                      
                                    </tr>
                                    @include('client.pop_up.pop_up_Note_seller',['tgx'=>$row["tgx"],'provider_01'=>$row["provider"],'Note'=>$row["Note"]])
                                    @include('client.pop_up.pop_up_edit_reservation_seller',['tgx'=>$row["tgx"],'provider_01'=>$row["provider"]])
    
                                    @endforeach 
                                </tbody>
                            </table>

                    
    </div>
     <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
     <script src="{{asset('assets/js/libs/jquery-3.1.1.min.js')}}"></script>
     <script src="{{asset('bootstrap/js/popper.min.js')}}"></script>
     {{-- <script src="{{asset('bootstrap/js/bootstrap.min.js')}}"></script> --}}
     <script src="{{asset('plugins/perfect-scrollbar/perfect-scrollbar.min.js')}}"></script>
     <script src="{{asset('assets/js/app.js')}}"></script>
     
     <script>
         $(document).ready(function() {
             App.init();
         });
     </script>
    <script src="{{asset('plugins/table/datatable/datatables01.js')}}"></script>
    <script src="{{asset('assets/js/custom.js')}}"></script>
    <script>        
        $('#default-ordering').DataTable( {
            "dom": "<'dt--top-section'<'row'<'col-12 col-sm-6 d-flex justify-content-sm-start justify-content-center'l><'col-12 col-sm-6 d-flex justify-content-sm-end justify-content-center mt-sm-0 mt-3'f>>>" +
        "<'table-responsive'tr>" +
        "<'dt--bottom-section d-sm-flex justify-content-sm-between text-center'<'dt--pages-count  mb-sm-0 mb-3'i><'dt--pagination'p>>",
            "oLanguage": {
                "oPaginate": { "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>', "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>' },
                "sInfo": "Showing page _PAGE_ of _PAGES_",
                "sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
                "sSearchPlaceholder": "Search...",
            //    "sLengthMenu": "Results :  _MENU_",
            },
            "order": [[ 6, "asc" ]],
            // "stripeClasses": [],
            "lengthMenu": [100, 200, 300, 400],
            "pageLength": 200,
            drawCallback: function () { $('.dataTables_paginate > .pagination').addClass(' pagination-style-13 pagination-bordered'); }
	    } );
    </script>
    <style>

        /* NOTE */
.text p {
  font-family: Comic Sans, helvetica, arial, sans-serif;
}

.note {
	/* float: left;
	display: block;
	position: relative; */
	padding: 1em;
	/* width: 574px; */
	min-height: 230px;
	margin: 0 0px 1px 0;
	background: linear-gradient(top, rgba(0,0,0,.05), rgba(0,0,0,.25));
	background-color: #2e2e2e;
	box-shadow: 5px 5px 10px -2px rgba(33,33,33,.3);
	transform: rotate(2deg);
	transform: skew(0deg,0deg);
	transition: transform .15s;
	z-index: 1;

}
.note:hover {
  cursor: move;
}


	textarea {
		color: white;
		background-color: transparent;
		border: none;
		resize: vertical;
		font-family: "Gloria Hallelujah", cursive;
		width: 100%;
    height: 59%;
		padding: 5px;
    font-size: 12pt;
}

textarea:focus {
			outline: none;
			border: none;
			box-shadow: 0 0 5px 1px rgba(0,0,0,.2) inset;
}
		



	</style>
  
    @endsection
